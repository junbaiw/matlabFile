function [marked, marked_data]=dnr_make_frequenceTabel(data,RangofMark)
%Categorical assessments, 
%Transfer the continues data points to user defined cagegorical data.
%Currently, only count the absolute difference
%Input: data is a mxn matrise
%        RangofMark=(0,1.1,1.4,2)
marked_data=zeros(size(data));
lnof_RangofMark=length(RangofMark);
for i=1:lnof_RangofMark
   if i<lnof_RangofMark
     numof_cond{i}=(RangofMark(i)<=abs(data) & abs(data)< RangofMark(i+1)).*i; %low change %median change
   elseif i==lnof_RangofMark
     numof_cond{i}=(RangofMark(i)<=abs(data)).*i; %high change
   end
   marked_data=marked_data+numof_cond{i};
end
 marked=1:lnof_RangofMark;