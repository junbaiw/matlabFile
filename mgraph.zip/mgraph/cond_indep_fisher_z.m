function [CI, r, p] = cond_indep_fisher_z(X, Y, S, C, N, alpha)
% COND_INDEP_FISHER_Z Test if X indep Y given Z using Fisher's Z test
% CI = cond_indep_fisher_z(X, Y, S, C, N, alpha)
%
% C is the covariance (or correlation) matrix
% N is the sample size
% alpha is the significance level (default: 0.05)
%
% See p133 of T. Anderson, "An Intro. to Multivariate Statistical Analysis", 1984

if nargin < 6, alpha = 0.05; end

r = partial_corr_coef(C, X, Y, S);
%added jbw
z = 0.5*log( abs(1+r)/abs(1-r) );
%end added
z0 = 0;


%if sample size N too small ??Oct 12.2003
W = sqrt(N - length(S) - 3)*(z-z0); % W ~ N(0,1)
%cutoff = norminv(1 - 0.5*alpha); % P(|W| <= cutoff) = 0.95
cutoff = mynorminv(1 - 0.5*alpha); % P(|W| <= cutoff) = 0.95
if abs(W) < cutoff
  CI = 1;
else % reject the null hypothesis that rho = 0
  CI = 0;
end
%p = normcdf(W);
p = mynormcdf(W);
