function MGraph_model2Graph(selected_model,orderof_Gp,cellLabels)
%make graph from G-logline model
%{'Expression','Genom','Sex','Age'}

if nargin<3,
%  labels = cellstr(char(zeros(N,1)+double('+')));
  cellLabels = cellstr(int2str((1:length(orderof_Gp))'));
end;

lnof_Gp=length(orderof_Gp);
for i=1:lnof_Gp
    labelof_Gp(i)=char(64+orderof_Gp(i));
end
G_matris=zeros(lnof_Gp,lnof_Gp);
lnof_model=length(selected_model);
for i=1:lnof_model
   tempStr=selected_model{i};
   lnof_tempStr=length(tempStr);
   for ji=1:lnof_tempStr
      for jj=ji+1:lnof_tempStr
         idx_i=findstr(tempStr(ji),labelof_Gp);
         idx_j=findstr(tempStr(jj),labelof_Gp);
         G_matris(idx_i,idx_j)=1;
         G_matris(idx_j,idx_i)=1;
      end
   end
end%end i
draw_graph(G_matris,cellLabels);   