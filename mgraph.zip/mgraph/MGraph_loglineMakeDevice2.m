function device=MGraph_loglineMakeDevice2(testdata, numof_col,tmp,sread,rb,rc,max_numofIdx)
%make device for one row or one column data
%
 tmp_base=[];
device=0;
    tmp_data=testdata;
    idx=1;
            while idx<=max_numofIdx
              for ii=1:rb
                for jj=1:rc
                 tmp_idx=tmp{ii,jj};
                 tmp_idxi=tmp_idx(idx,1);
                 tmp_idxj=tmp_idx(idx,2);
                 tmp_base(ii,jj)=tmp_data(tmp_idxi,tmp_idxj);
                 end
               end
               %calculate device
               %tmp_base
                 total_base=sum(sum(tmp_base));
                 sumrow=sum(tmp_base,2);
                 sumcol=sum(tmp_base,1);
                for ki=1:rb
                  for kj=1:rc
                     if tmp_base(ki,kj)~=0
                         device=device+tmp_base(ki,kj)*log(tmp_base(ki,kj)/sumrow(ki)/sumcol(kj)*total_base);
                     end
                   end
                 end
                 idx=idx+1;
               end %end while
             device=device*2;
            %tdevice(sread(name_rb),sread(name_rc))=device;