function device=MGraph_loglineMakeDevice1(testdata, numof_col,tmp,sread,rb,rc,max_numofIdx,roworcol)
%make device for both row or both column data
%roworcol==1 for row
%roworcol==2 for column
tmp_base=[];
device=0;
    for i=1:numof_col %for row data
        if roworcol==1
         tmp_data=testdata(:,i); %for row
        else
         tmp_data=testdata(i,:); %for column
        end
       idx=1;
       while idx<=max_numofIdx
              for ii=1:rb
                for jj=1:rc
                 tmp_idx=tmp{ii,jj};
                 tmp_base(ii,jj)=tmp_data(tmp_idx(idx));
                 end
               end
               %calculate device
                 total_base=sum(sum(tmp_base));
                 sumrow=sum(tmp_base,2);
                 sumcol=sum(tmp_base,1);
               for ki=1:rb
                  for kj=1:rc
                     if tmp_base(ki,kj)~=0
                           device=device+tmp_base(ki,kj)*log(tmp_base(ki,kj)/sumrow(ki)/sumcol(kj)*total_base);
                     end
                   end
                end
                %pause
                idx=idx+1;
            end %end while
       end
       device=device*2;
       %tdevice(sread(name_rb),sread(name_rc))=device;