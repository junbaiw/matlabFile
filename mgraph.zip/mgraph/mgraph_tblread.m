function [data,varnames,casenames]=mgraph_tblread(filename)
%deblank
% the input Cluster file should be tab deliments text file format
%otherwise this function will not work.
%Version 3.0
clear tempdata inputdata outputdata

t0=clock;

[fid,msg]=fopen(filename,'rt');
if fid<0
    error('Can not open file');
end
idx=1;
findInf=0;
finddata=0;
enddata=0;
idxdata=1;
while 1
    tline = fgets(fid);
    if ~ischar(tline)
        break,
    end
    if findInf==0
       colname=marray_tabassign(tline,1)   %this is for check column names 
       lncolname=length(colname);
       for i=2:lncolname
           tempname=strrep(deblank(colname{i}),'._','');
           tempname=strrep(tempname,' ','_');
           name{i-1}=tempname;
       end
       tempdata2=cell(10000,1);
       temp=zeros(10000,lncolname-1);         
       findInf=1;   
    else  %end if Block reading the first line
         %read data from second row    
         varcol=marray_tabassign2(tline,lncolname);
         tempdata2(idxdata)=varcol(1);
        varcol(2:lncolname) 
	temp(idxdata,:)=str2num(strvcat(deblank(strrep(varcol(2:lncolname),'_',''))))';
         idxdata=idxdata+1;
     end     
end
fclose(fid);
tt=etime(clock,t0);


tempname=strvcat(colname{1});
tempcolID=cellstr(strvcat(tempdata2{1:idxdata-1}));
    
inputdata.sample=name;
%eval(['inputdata.',tempname,'=tempcolID;']);
inputdata.data=temp(1:idxdata-1,:);
inputdata.colnum=lncolname-1;

data=inputdata.data;
varnames=strvcat(inputdata.sample);
casenames=strvcat(tempcolID);
tt=etime(clock,t0);
