function [a,mtc]=wang_nexksb(n,k,a,mtc)
%generate subsets of a sets n with k elements
%in each subset
%
global m2 h
if k>0
    if mtc %30 
        if m2<n-h %40
            h=0;
        end 
        h=h+1;
        m2=a(k+1-h);
        
        for j=1:h
            a(k+j-h)=m2+j;
        end
        mtc=a(1)~=(n-k+1);
        
    else
        m2=0;
        h=k;
        for j=1:h
            a(k+j-h)=m2+j;
        end
        mtc=a(1)~=(n-k+1);
    end
 else 
     for i=1:n
         a(i)=0;
     end
     mtc=0;
 end
