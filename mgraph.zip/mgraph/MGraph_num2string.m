function stringVector=MGraph_num2string(numberVector)
%input number of edge location
%output corresponding the string name for example
%Input [ 1 2; 2 3]
%Output {AB; BC}
[r c]=size(numberVector);
for i=1:r
   tempNum=numberVector(i,:);
   tempString=[];
   for j=1:length(tempNum)
       if j<=26
        tempString=strcat(tempString,char(64+tempNum(j)));
       else
           tempString=strcat(tempString,char(64+6+tempNum(j)));
       end 
   end
   stringVector{i}=tempString;
end

