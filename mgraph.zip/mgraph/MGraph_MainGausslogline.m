function result=MGraph_MainGausslogline(testdata,numofGin_X,sread,columnStart)
%Graphical logline modle for discrete data
%
%test data 1
%initial number
%testdata=[15 23 25 14; 9 14 46 47; 30 22 22 8; 32 16 27 12]
%testdata=[ 44 40 112 67; 129 145 12 23; 35 12 80 33; 109 67 7 9; 23 32 70 66; 50 80 7 13; ...
%          24 25 73 57; 51 63 7 16; 5 7 21 9; 9 17 1 4; 4 3 11 8; ...
%          14 17 5 2; 7 3 14 14; 9 16 2 3; 4 0 13 11; 5 14 4 4 ];
%numofGin_X=[2,2,2,2,2,2];
%sread=[6,5,4,3,2,1];

%test
%numofGin_X=numoftype_ineachGp;
%sread=orderof_Gp;

%
%test analgesic trial degree freedrom was wrong
%testdata=[3 20 5 11 14 8 3 14 12 6 13 5 12 12 0 11 10 0 3 9 4 6 9 3 ];
%numofGin_X=[2,2,2,3]
%sread=[1,2,3,4]
%cutoff_P=0.05;
%columnStart=1;
%end test
%numofGin_X=[2,2,2,2,2,2]
%sread=[1,2,3,4,5,6]
%cutoff_P=0.05;
%columnStart=4;
%end tset2

size_data=size(testdata);
numof_row=size_data(1);
numof_col=size_data(2);
numofVar=length(sread); %4
%numof_Gnum=numofVar; %numof_row;

result=MGraph_loglineMakeTableIndex(numofGin_X,size_data,numofVar,sread,columnStart,testdata);
for kki=1:numofVar-1
    for kkj=kki+1:numofVar
    name_rb=kki;
    name_rc=kkj;
    real_i=sread(name_rb);
    real_j=sread(name_rc);
    %pause
    %make the matrise for the missing edge 
    %for example group 2,3 is indepedent (missing) other variable as the given condition
    %if the table contain zero than have trouble in df!!! nov12.2002
    %I have to check the zero in data set!
    %
    %Currently, if there are one zero entry in the cell then the degree
    %of freedom is minus 1, added Nov14.2002
    rb=result.numoftype_ineachGp(name_rb);
    rc=result.numoftype_ineachGp(name_rc);
    %this one have to be check
    total_numofcell=prod(result.numoftype_ineachGp);%result.sizeof_data(1)*result.sizeof_data(2);
    ra=(total_numofcell)/rb/rc;
    df=ra*(rb-1)*(rc-1);%-result.df_minus(name_rb)-result.df_minus(name_rc);
    if real_i>real_j %force the results in low part of the matrise
        result.df(real_i,real_j)=df;%degree of freedom
        result.table{real_i,real_j}=sprintf(['There are, ',num2str(ra),' ', num2str(rb),'x',num2str(rc), 'tables']);
    else
        result.df(real_j,real_i)=df;%degree of freedom
        result.table{real_j,real_i}=sprintf(['There are, ',num2str(ra),' ', num2str(rb),'x',num2str(rc), 'tables']);
    end
    gp2=result.groupidx{name_rb};
    gp3=result.groupidx{name_rc};
    size_gp2=size(gp2);
    size_gp3=size(gp3);

    gp2_idxgp=MGraph_loglineSortIdxgp(size_gp2(1),gp2,rb);
    gp3_idxgp=MGraph_loglineSortIdxgp(size_gp3(1),gp3,rc);
    
    %start make rb x rc tables
    if (name_rb<result.startnumof_Col & name_rc<result.startnumof_Col)|...
            (name_rb>=result.startnumof_Col & name_rc>=result.startnumof_Col)% for row data
      for i=1:rb
        for j=1:rc
         tmp{i,j}= intersect(gp2_idxgp{i},gp3_idxgp{j});
        end
      end
    else %if name_rb < result.startnumof_Col & name_rc>= result.startnumof_Col % for column data, it need check and modife base calculae!!!
    %%5.4.2002
        for i=1:rb
            for j=1:rc
                tmpgp2=gp2_idxgp{i};
                lengp2=length(tmpgp2);
                tmpgp3=gp3_idxgp{j};
                lengp3=length(tmpgp3);
                tmpgp22=repmat(tmpgp2,1,lengp3);
                tmpgp22=reshape(tmpgp22,lengp2*lengp3,1);
                tmpgp33=repmat(tmpgp3,1,lengp2)' ;
                tmpgp33=reshape(tmpgp33,lengp2*lengp3,1);
                tmp{i,j}=[tmpgp22,tmpgp33];
            end
         end
     end
     %tmp_base=[];
     max_numofIdx=size(tmp{1,1},1);
     %device=0;
     if (name_rb<result.startnumof_Col & name_rc<result.startnumof_Col) % for both row data
         roworcol=1;
         device=MGraph_loglineMakeDevice1(testdata, numof_col,tmp,sread,rb,rc,max_numofIdx,roworcol);
     elseif (name_rb>=result.startnumof_Col & name_rc>=result.startnumof_Col) %for both column data
        roworcol=2;
        device=MGraph_loglineMakeDevice1(testdata, numof_row,tmp,sread,rb,rc,max_numofIdx,roworcol);
     else
         device=MGraph_loglineMakeDevice2(testdata, numof_col,tmp,sread,rb,rc,max_numofIdx);
     end
     %[name_rb,name_rc]
     %sread(name_rb),sread(name_rc)
     %pause
     if real_i>real_j
        tdevice(real_i,real_j)=device;
     else
        tdevice(real_j,real_i)=device;
     end
 end
end
if length(sread)>1
    result.device=tdevice;
else
    result.device=0;
end