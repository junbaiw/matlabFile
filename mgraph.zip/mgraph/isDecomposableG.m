function isDecomposable=isDecomposableG(G)
%Input adj_mat of Graph
%Output 1 for decomposable graph , o for undecomposable graph
%
%draw_graph(G);
[row col]=size(G);
nodes=1:row;
num_of_nodes=length(nodes);

while 1
    isfound=0;
    %delete all simpical node from the nodes set
    for i=1:num_of_nodes
        if isSimplical_node(G,nodes(i))
            %it is simplical nodes and delete it from G
            temp_nodes=setdiff(nodes,nodes(i));
            nodes=[];
            nodes=1:length(temp_nodes);
            num_of_nodes=length(nodes);
            %make a new graph without node i and continue to search
             new_G=G(temp_nodes,temp_nodes);
             G=[];
             G=new_G;
             isfound=1;
            break;
        end
     end
     if isfound==0 & i==num_of_nodes
         %no more elimination
         break;
     elseif num_of_nodes==0;
         %delete all the nodes
         break;
     end
     %clf
     %draw_graph(G)
 end
 if isempty(nodes)
     isDecomposable=1;
 else
     isDecomposable=0;
 end