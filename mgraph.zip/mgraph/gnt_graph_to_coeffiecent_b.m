function b=gnt_graph_to_coeffiecent_b(G)
%Input: adj_matrix of the graph
%Output: coefficent of each vertex b
len_G=size(G,1);
parients={};
for i=1:len_G
    pari= parents(G, i);
    if (isempty(pari) & i==1)
        %root vertex
        parients{i}=[];
    elseif (isempty(pari) & i>1)
        parients{i}=zeros(1,i-1);
    elseif ~isempty(pari)
        temp_parients=zeros(1,i-1);
        temp_parients(pari)=1;
        parients{i}=temp_parients;
    else
        warndlg('Error in b coefficeint');
    end
end
b=parients;
