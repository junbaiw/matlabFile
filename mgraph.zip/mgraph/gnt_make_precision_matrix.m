function w=gnt_make_precision_matrix(v,b)
%estimated the precision matrix cov^-1 for gnt
%Input: v is the conditional variance, it is a vector
%b is the regression/linear coefficent of multi-normal distributions, it is a cell vector
%N(m+sum(b(x-m)),1/v);

len_of_variables=length(v);
w=zeros(len_of_variables,len_of_variables);
for i=1:len_of_variables
    if i==1
        w(i)=1/v(i);
    else
        temp_w=w(1:i-1,1:i-1)+b{i}'*b{i}/v(i);
        temp_w(end+1,:)=-b{i}/v(i); %add last row
        temp_w(1:end-1,end+1)=-b{i}'/v(i); % add last column
        temp_w(end,end)=1/v(i);
        w=temp_w;
        temp_w=[];
    end  
end

    