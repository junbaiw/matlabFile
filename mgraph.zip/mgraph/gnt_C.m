function c_n_alpha=gnt_C(n,alpha)
%compute the normalization coefficent C(n,alpha)
%something wrong with this function have to check the book??? sep16.2003
%
%c_n_alpha=1;
%weight=( 2^(alpha*n/2)*pi^(n*(n-1)/4) );
%for i=1:n
%    c_n_alpha=c_n_alpha*gamma((alpha+1-i)/2);
%end
%c_n_alpha=(c_n_alpha*weight)^-1;

c_n_alpha=0;
%modifed in Oct 2004
%weight=( 2^(alpha*n/2)*pi^(n*(n-1)/4) );
weight=log10(2)*(alpha*n/2)+log10(pi)*n*(n-1)/4;
for i=1:n
    c_n_alpha=c_n_alpha+(gammaln((alpha+1-i)/2))/log(10);
end
c_n_alpha=-1*(c_n_alpha+weight);
