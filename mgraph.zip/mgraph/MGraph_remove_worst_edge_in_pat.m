function G=MGraph_remove_worst_edge_in_pat(d,G,sigma,alpha,L,T0,TL)
%Input
%Output

[nr nc]=size(d);
u0=median(d);
n=nc;
L=nr;
sigma=nc+2;
alpha=nc+2;
v=ones(1,n);

current_score=(gnt_scoring_uncompleteG(G,sigma,alpha,L,T0,TL));

disp('Remove edge ...');
max_score=current_score;


while max_score<=current_score
    rA=[];
    rB=[];
    temp_r_edges={};
    rpscore=[];
    rev_score=[];
    temp_rev_edges={};
    both_p=[];
    idx=1;
    idx2=1;
    temp_graphs={};
    need_r_edge=[];
    done=0;
    tempG=[];
    
    %star test
    [rA rB]=find(abs(triu(G))==1); %potential remove edge/ another is revers edge ??
	idx_yes=find(rA<rB);
	new_A=rA(idx_yes);
	new_B=rB(idx_yes);
	rA=[];rB=[];
	rA=new_A;
	rB=new_B;
    
    %[rA,rB]
    %disp('Start remove edge ...')
    %pause
    
    for i=1:length(rA)
       if  rA(i)<rB(i)
            temp_rG=G;
            %remove edge
            %try to find unshielded between a b
             x=rA(i);y=rB(i);
            
             Z1=[];
             Z12=[];
             ZZ=[];
             Z1=[];
             
             Z1 = find(temp_rG(x,:));
             Z12=find(temp_rG(:,x))';
             ZZ=unique([Z1,Z12]);
             ZZ1 = mysetdiff(ZZ, y);
           
             
             Z2=[];
             Z22=[];
             ZZ=[];
             ZZ2=[];
             
             Z2 = find(temp_rG(y,:));
             Z22=find(temp_rG(:,y))';
             ZZ=unique([Z2,Z22]);
             ZZ2 = mysetdiff(ZZ, x);
             
             ZZZ=intersect(ZZ1,ZZ2);
             
             if ~isempty(ZZZ)
                 %have unshielder
                  len_zzz=length(ZZZ);
                 for ii=1:len_zzz
                     z=ZZZ(ii);
                    
                        temp_rG=G;
                        temp_rG(x,y)=0;
                        temp_rG(y,x)=0;
                        %fprintf('%d -> %d <- %d\n', x, y, z);
                        if (x<z & y<z)
                            temp_rG(x,z) = -1; temp_rG(z,x) = 0;
                            temp_rG(y,z) = -1; temp_rG(z,y) = 0;
                        else
                            temp_rG(x,z) = 1; temp_rG(z,x) = 1;
                            temp_rG(y,z) = 1; temp_rG(z,y) = 1;   
                        end
                        if ~isempty(find(temp_rG==-1))
                           % temp_rG
                           % disp('Remove unshilder');
                           % pause
                            temp_graphs{idx}=temp_rG;
                            rpscore(idx) = (gnt_scoring_uncompleteG(temp_rG,sigma,alpha,L,T0,TL));
                            idx=idx+1;
                        end
                     
                end
            else
                %non unshielder
                temp_rG=G;
                temp_rG(x,y)=0;
                temp_rG(y,x)=0;
               
               % if ~MGraph_isundirected(temp_rG)
                if ~isempty(find(temp_rG==-1))
                   % temp_rG
                   % disp('remove edg')
                    temp_graphs{idx}=temp_rG;
                    rpscore(idx) = (gnt_scoring_uncompleteG(temp_rG,sigma,alpha,L,T0,TL));
                    idx=idx+1;
                end
            end
        end %end if
      end %end for
     
      
      if ~isempty(temp_graphs)
            [best_rpscore best_rp]=max(rpscore);
            best_graph=temp_graphs{best_rp}; 
             
            current_score=best_rpscore;
            current_G=best_graph;
        
            done=1;
        else
            done=1;
        end
    
    if current_score>max_score;
        disp('Remove edge')
        max_score=current_score;
        G=current_G;
        ischanged=1;
        %need_r_edge
        %best_r_edge
    elseif current_score==max_score & done
        break;
    end
end
