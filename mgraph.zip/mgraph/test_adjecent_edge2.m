function [diffV ,adjecentV]=test_adjecent_edge2(len_of_vertices,new_model,add_edge,start_location)
%find adjecent edge of add_edge1 in new_model
%
adjecentV=[];
idx_reco=1;
first_model=new_model{start_location};
intersectV=intersect(first_model,add_edge(1));
diffV=setdiff(first_model,add_edge(1));
len_of_diffV=length(diffV);
old_intersectV=intersectV;
old_diffV=diffV;
if ~isempty(intersectV)
    
    for j=1:len_of_diffV  
        adjecentV{idx_reco}=old_intersectV;
        idx_reco=idx_reco+1;
        %then we continue to search for the path
        diffV=old_diffV(j);
        for i=1:len_of_vertices
            if i~=start_location
                %try find the path
                intersectV=intersect(new_model{i},diffV);
                if (~isempty(intersectV) )
                    adjecentV{idx_reco}=intersectV;
                    idx_reco=idx_reco+1;
                    diffV=setdiff(new_model{i},diffV)
                    if ismember(add_edge(2),diffV)
                        %we find the path and stop
                        adjecentV{idx_reco}=add_edge(2);
                        break;
                    end
                else
                    adjecentV{idx_reco}=[];  
                    idx_reco=idx_reco+1;
                end
            end
        end %end for
        idx_reco=1;
    end %end for
else
    adjecentV=[];
end
