function outdata=MGraph_loadDataforLogline(filename)
%make a function for input data in logline
%filename='test_inputData.txt'
[fid,msg]=fopen(filename,'rt');
if fid<0
    error('Can not open file');
end
idx=1;
finddata=0;
enddata=0;
idxdata=1;
while 1
    tline = fgets(fid);
    if ~ischar(tline)
        break,
    end  
 	%read data
    t1=tline ; %check is it a parameter
    if isempty(findstr(t1,'%'))  %if it is not % then start read 4 line parameter
       if isempty(findstr(t1,'!')) %check whether it is end of data
          if idxdata<6
       		idx_end=findstr(tline,':'); %find where paremt end
             tempStr=tline(1:idx_end-1);
          	else
             tempStr=tline;
          end
          if idxdata==2
          		outdata.numoftype_ineachGp=str2num(tempStr);  
       	elseif idxdata==3
          		outdata.orderof_Gp=str2num(tempStr);
       	elseif idxdata==4
          		outdata.cutoff_P=str2num(tempStr);
       	elseif idxdata==5
             outdata.columnStart=str2num(tempStr);
          elseif idxdata==1
             outdata.labels=tempStr;
       	else
           % idxdata
           % tempStr
          		outdata.data(idxdata-5,:)=str2num(tempStr);  
       	end %end case
       	idxdata=idxdata+1;
       end %end !
    end  %end if
 end %end while
 fclose(fid);