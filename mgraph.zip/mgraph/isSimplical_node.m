function isSim=isSimplical_node(G,i)
%test node i whether it is simplical node in graph G
%
nb_i=neighbors(G,i);
sub_setnb=G(nb_i,nb_i);
len_nb_i=length(nb_i);
isSim=(len_nb_i^2-len_nb_i)/2==sum(sum(triu(sub_setnb)));
        %it is simplicial nodes then 1