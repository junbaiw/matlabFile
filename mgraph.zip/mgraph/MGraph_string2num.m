function numberVector=MGraph_string2num(stringVector)
%Input {'AB','BC'}
%Output [ 1 2 ; 2 3];
%maximun 26 x 26 matrise
[r c]=size(stringVector);
tempNum=[];
stringOrder={'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'};
for i=1:c
   tempString=stringVector{i};
   for j=1:length(tempString)
      tempNum(j)=findstr(tempString(j),strvcat(stringOrder));
   end
%   if ~isempty(tempNum)
    numberVector(i,:)=tempNum;
%   else
%    numberVector(i,:)=0;
%   end
end

