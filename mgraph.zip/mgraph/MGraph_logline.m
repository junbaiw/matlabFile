global htxt2 ind1 init_fig ficonmessagesbg table table_fig plot_fig
global file1 path1 data 
%bellow is object handle
global l_openBut1 l_htxt_cutoffP l_Brun graph_form

set(0,'ShowHiddenHandles','on')
if ( ~exist('GUIFl') ) 
    %close all hidden;
   set(init_fig,'Name','MGraph - Graphical loglinear model',...
       'Position',[0.1 0.07 0.55 0.70]);
   clf(init_fig);
  % if exist('ficonmessagesbg');
  %    delete(ficonmessagesbg);
  %    clear ficonmessagesbg;
  %end
   GUIFl=0;
   plot_fig=12;
   %Default input values
   runcode=0;
   cutoff_P=[];
   graph_form=1;
   %output   
end;

if GUIFl==0
   fmenu=uimenu('Label','MGraph');
    uimenu(fmenu,'Label','MGraph Properties','Callback','MGraph_properties');
 uimenu(fmenu,'Label','Graphical loglinear model','Callback',['clf(init_fig);MGraph_logline']);
    uimenu(fmenu,'Label','Graphical gaussion model','Callback',[ 'clf(init_fig);MGraph_gauss']);
    uimenu(fmenu,'Label','Quit','Callback',['clear all;close all hidden'],...
           'Separator','on','Accelerator','Q');
    dmenu=uimenu('Label','MGraph Debug'); 
    uimenu(dmenu,'Label','MGraph Debug','Callback','marray_debug'); 

   %Default input values
   global t1 htxt        

   
   axHndl=init_fig;
   set(init_fig,'Name','MGraph - Graphical loglinear model');
   %text
   htxt2 =uicontrol('Parent',axHndl,... % 'Units', 'normalized', ...
		    'Style', 'text', ...
		    'Position', [180 120 250 150], ...     %[.3 .1  .55 0.7],...
		    'Backg', [1 1 1], ...
		    'Foreg', [0 0 0], ...
          'String', ['                                                                                   Graphical loglinear model'], ...
		    'FontUnits', 'Normalized',...
		    'FontWeight',  'bold', ...
		    'HorizontalAlignment', 'center', ...
		    'Tag', 'genetext');
 
   l_Brun=uicontrol('Parent',axHndl,'style','push','string','Run program',...
      'position',[10 40 90 30 ], ...
   'callback', ['runcode=1;clf(init_fig);MGraph_logline;' ], ...
   'Interruptible','on');

 
%following is function
	%Open Input file1
	l_openBut1=uicontrol('Parent',axHndl,'style','push','string','Load input file',...
	'position',[10 350 150 30], ...
	'callback', [' [file1, path1]=uigetfile({''*.*'', ''All Files (*.*)''});clf(init_fig);MGraph_logline;'],...
	'Interruptible','on');
	if exist('file1')
 	file_name1=uicontrol('Parent',axHndl,'Style','text','HorizontalAlignment','left',...
 	'Position',[10 295 150 30],...
 	'String', file1); 
	end
   
   
%open input parameter
l_htxt_cutoffP=uicontrol('Parent',init_fig,... % 'Units', 'normalized', ...
		    'Style', 'text', ...
		    'Position',[10 200 90 20],... % [.02 .55  .25  0.05],...
		    'Backg', [1 1 1], ...
		    'Foreg', [0 0 0], ...
		    'String','Significance P=', ...
		    'FontUnits', 'Normalized',...    %'FontSize',  0.01, ...
		    'FontWeight',  'bold', ...
		    'HorizontalAlignment', 'left', ...
          'Tag', 'cutoffP','BackgroundColor','yellow');
 cutoffP_field=uicontrol('Parent',init_fig,'Style','edit','Position', [10 180 90 20], ... %[.02 .48 .2  0.05],...
         'BackgroundColor','white',...
         'CallBack',['cutoff_P=str2num(get(cutoffP_field,''String''));']);
      

   if runcode==1 %start running     
      if exist('hwaite') 
         close(hwaite);
         clear hwaite;
      end
      
         
      table=[];
    marray_debuge(char(10));  
    marray_debuge('Start Running ...............');
    
    %read input data
    hwaite=waitbar(0,'Please wait....');
    outdata=MGraph_loadDataforLogline([path1,file1]);
    testdata=outdata.data;
    numoftype_ineachGp=outdata.numoftype_ineachGp;
    orderof_Gp=outdata.orderof_Gp;
    columnStart=outdata.columnStart;    
    waitbar(1/4,hwaite);
    
    %get cuttoff of P value
    if ~isempty(cutoff_P)
          set(cutoffP_field,'String',num2str(cutoff_P));
   else
       set(cutoffP_field,'String',num2str(0.05)); %default cut off P     
       cutoff_P=0.05;
       marray_debuge('Use default P=0.05');
    end
	outdata.cutoff_P=cutoff_P;
        
    marray_debuge(['Load file ',file1]);
    marray_debuge(['Reading parameter' ]);
    marray_debuge(['Order of group labels, ',num2str(outdata.orderof_Gp)]);
    marray_debuge(['Number of type in each group, ',num2str(outdata.numoftype_ineachGp)]);
    marray_debuge(['Column start number, ', num2str(outdata.columnStart)]);
    marray_debuge(['Significance P=',num2str(cutoff_P)]); 
    waitbar(2/4,hwaite);
    
    %compute variance
    selected_model=MGraph_loglineModel(testdata,numoftype_ineachGp,orderof_Gp,columnStart,cutoff_P);
    
    
    %draw figures
    clear cell_labels cell_labelsName
    lnof_Gp=length(orderof_Gp);
    comaIdx=findstr(outdata.labels,',');
    bg_idx=1;
    for i=1:lnof_Gp
       cell_labels{i}=char(64+orderof_Gp(i));
       if i<lnof_Gp
          cell_labelsName{i}=strrep(deblank(outdata.labels(bg_idx:comaIdx(i)-1)),'"','');
          bg_idx=comaIdx(i)+1;

       else
          cell_labelsName{i}=outdata.labels(bg_idx:end);
       end
     end

    set(init_fig,'Visible','off');
    figure(plot_fig);
    clf(plot_fig);
    MGraph_model2Graph(selected_model,orderof_Gp,cell_labelsName);
    waitbar(3/4,hwaite);
    set(init_fig,'Visible','on');
    waitbar(1,hwaite);
    close(hwaite); 
    clear hwaite
    marray_debuge(strvcat(cellstr([{'Cell labels:'},cell_labels])));
    marray_debuge(strvcat(cellstr([{'Cell label''s name:'}, cell_labelsName])));
    runcode=0;   
    
  end %end run 
end; %end all




