function outdata=MGraph_loadDataforGauss(filename)
%make a function for input data in logline
%filename='test_inputDataGauss.txt'
%for no lable of column name
[fid,msg]=fopen(filename,'rt');
if fid<0
    error('Can not open file');
end
idx=1;
finddata=0;
enddata=0;
idxdata=1;
while 1
    tline = fgets(fid)
    if ~ischar(tline)
        break,
    end  
 	%read data
    t1=tline(1) ; %check is it a parameter
    if ~strcmp(t1,'%')  %if it is not % then start read 4 line parameter
       if ~strcmp(t1,'!') %check whether it is end of data
          if idxdata<4
       		idx_end=findstr(tline,':'); %find where paremt end
             tempStr=tline(1:idx_end-1);
          	else
             tempStr=tline;
          end
          tempStr
       	if idxdata==1
          		outdata.N=str2num(tempStr);  
       	elseif idxdata==2
          		outdata.q=str2num(tempStr);
       	elseif idxdata==3
          		outdata.cutoff_P=str2num(tempStr);
          else
          		outdata.data(idxdata-3,:)=str2num(tempStr);  
       	end %end case
       	idxdata=idxdata+1;
       end %end !
    end  %end if
  end %end while
 