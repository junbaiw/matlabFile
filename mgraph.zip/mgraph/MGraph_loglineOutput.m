function [removeEG, needtestEG]=MGraph_loglineOutput(out)
global graph_form

lnofvar=length(out.numoftype_ineachGp);
rem_idx=1;
idx=1;
removeEG.P=0;
removeEG.name={};
string_name=sort(out.labelof_Gp); %out.labelof_Gp(out.orderof_Gp); %reorder the string as ABCDEF.....
%because in the out results, the device is arranged as ABCDEF.. order in the matrise

%if out.numof_Gp==1
 for i=1:lnofvar-1 %only select low part of matrise
     for j=i+1:lnofvar
        temp_device=out.device(j,i);
        temp_df=out.df(j,i)-out.df_minus(j)-out.df_minus(i); %remove one df if one entry of cell is zero
        temp_P=Chisq(temp_device,temp_df); %Chi squr test
        
        %added 12.05 for test decomposiable model
        %make new subgroup
        delet_edge_location=[j,i];
        delet_edge_string=cellstr(string_name(delet_edge_location));
        %delet_edge_string=MGraph_num2string(delet_edge_location);
        temp_newModel=sort(cellstr(out.new_model));
        new_model=MGraph_makeSubGraph(temp_newModel,delet_edge_string);
        clear numberVector
        for new_idx=1:length(new_model)
          		numberVector{new_idx}=num2str(MGraph_string2num(new_model(new_idx)));
        end
        input_k_cliques=(numberVector)';
          
        if graph_form==1 %decomposable modle
         		 is_SDordering=MGraph_isSDordering(input_k_cliques);
        elseif graph_form==2
                is_SDordering=1;
        else
             error('Please select graphical model in ''MGraph properties''!, Program stop!');
             break;
        end    
        %end added 12.05
        
        
        if (temp_P>=out.cutoff_P & is_SDordering==1)   
           %only decomposiable model include at here 
           temp_string{idx}=sprintf(['[',string_name(j),'', string_name(i),'] Dev=',num2str(temp_device)...
                ,' Df=',num2str(temp_df),' P=',num2str(temp_P)]);
            %display string
            
            temp_remove=temp_P;
            needtestEG.allLocation(rem_idx,:)=[j,i];
            needtestEG.allname{rem_idx}=['[',string_name(j),'',string_name(i),']'];
            rem_idx=rem_idx+1;
            if temp_remove>removeEG.P %record the edge who had the biggest P value 
                removeEG.P=Chisq(temp_device,out.df(j,i)); %temp_remove;
                removeEG.df=out.df(j,i); %test the total device of remove one edge donot remove one edge
                removeEG.device=temp_device;
                removeEG.name=['[',string_name(j),'',string_name(i),']'];
                removeEG.location=[j,i];
             end 
        else
            temp_string{idx}=sprintf(['[',string_name(j),'', string_name(i),'] Dev=',num2str(temp_device)...
                ,' Df=',num2str(temp_df),' P=',num2str(temp_P),' +']);
        end
        idx=idx+1;
    end
end %end for

temp_string{idx}=['Model: ', string_name];
strvcat(temp_string); %display output results
marray_debuge(strvcat(temp_string));

removeEG.model=string_name;
needtestEG.model=string_name;

%make new subgroup here possibile have a bug 12.05 refer MGraph_makesubgraph??
if ~isempty(removeEG.name)
    for i=1:length(removeEG.location)
        temp_model=setdiff(out.orderof_Gp,removeEG.location(i));
        temp_new=string_name(temp_model);
        new_model{i}=temp_new;
     end
    removeEG.new_model=new_model;
end
%new_model
%else %end numof_Gp=1
% disp('not available');    
%end

    