function [cond4,filtered_redsub, filtered_greensub]=mcgh_filter(inputdata)
global stdBackIn
data=inputdata;
%%%%%%%%%%%%%%%%%%%%%%%%%%5
%start filtering data set
ch1=leond_repData(data.ch1_Intensity);
ch1_bg=leond_repData(data.ch1_Background); 
ch1_bgSDV=leond_repData(data.ch1_Background_Std_Dev);
ch2=leond_repData(data.ch2_Intensity);
ch2_bg=leond_repData(data.ch2_Background);
ch2_bgSDV=leond_repData(data.ch2_Background_Std_Dev);

ch1=str2num(strvcat(ch1));
ch1_bg=str2num(strvcat(ch1_bg));
ch1_bgSDV=str2num(strvcat(ch1_bgSDV));

ignorflag=str2num(strvcat(data.Ignore_Filter));
name=lower(data.Name);

ch2=str2num(strvcat(ch2));
ch2_bg=str2num(strvcat(ch2_bg));
ch2_bgSDV=str2num(strvcat(ch2_bgSDV));

%part 1 find empty spots
idxempty=strmatch('empty',lower(name));
idxblank=strmatch('-',lower(name)); 
idxnull=strmatch('null',lower(name)); 
idxunknown=strmatch('unknown',lower(name)); %it's possibile other character means empty spots
                                    %but we should force it has a standard !!
qualtScore=ignorflag; %quality score, 0 is minimumm, 1 is maximum assign manually falgged 
qualtScore(idxempty,:)=0;  %assign zero to empty spots.
qualtScore(idxblank,:)=0;
qualtScore(idxunknown,:)=0; %these spots should have quality score =0;!!
qualtScore(idxnull,:)=0;

%part 2 find all spots, without flaged and empty ones
idxgood=find(qualtScore~=0);
idxnonempty=idxgood;
numofSpots=length(data.Row);
marray_debuge(['Total number of Spots :', num2str(numofSpots)]);
marray_debuge(['Number of empty and flagged spots :',num2str(numofSpots-size(idxgood,1))]);
marray_debuge(['Those spots will not included in further data analysis!']);

%find median background signal intensity of Ch1 and Ch2

minIntensity_ch1=median(ch1_bg(idxgood)+(stdBackIn-1)*ch1_bgSDV(idxgood));
minIntensity_ch2=median(ch2_bg(idxgood)+(stdBackIn-1)*ch2_bgSDV(idxgood));
marray_debuge(['Median(Background_Int + ',num2str(stdBackIn-1), '*Background_IntSDV) in Ch1=',...
        num2str(minIntensity_ch1),'; Ch2=',num2str(minIntensity_ch2)]);

ch1_redsub=(ch1-ch1_bg);  %not include flaged and empty spots
ch2_greensub=(ch2-ch2_bg);

%find weak spots whose intensity is smaller than Back_intensity+2*Back_intensity_STD
cond1=(ch1_bg>=0 & ch2_bg>=0 & ch1>0 & ch2>0 & ch1_redsub>0 & ch2_greensub>0 );
      marray_debuge('(Intensity -Background Intensity)> 0');
cond2=(ch1>=minIntensity_ch1 & ch2 >=minIntensity_ch2);
marray_debuge(['Intensity before substrate the background >= median(bk+',num2str(stdBackIn-1),'*bk_std)'] );

cond3= (cond1==1 & cond2==1 );
cond4=cond3.*qualtScore; %replace ignored spot as zero;

filtered_redsub=cond4.*ch1_redsub;
filtered_greensub=cond4.*ch2_greensub;
total_filtered=length(find(cond4==0));
marray_debuge(['Total filtered spots ', num2str(total_filtered)] );
