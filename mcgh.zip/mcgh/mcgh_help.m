 if exist('HelpfigNumber')
     if HelpfigNumber~=1335 
     %    delete(HelpfigNumber);
     clear HelpfigNumber;
     end;
 end;
   
HelpfigNumber=1335;
titleStr='M-CGH';
[txtHndlList,HelpfigNumber]=mcgh_comp_help(titleStr,HelpfigNumber);