function [inputdata,colname]=marray_testload_marray_harbison(filename)
%deblank
% the input QuantArray file should be tab deliments text file format
%otherwise this function will not work.
%Version 3.0
%strread not work for matlab 5.0
%
clear tempdata inputdata outputdata tempname colname tempdata2

t0=clock;
%filename='slide32c011001Export.txtOUT' %'FMEXForw.txtOUT' %'Vg_GPiX_out2.gprOUT' %'Export34For.txtOUT'; %'5.10TPAExport.txt'
%tempdata=[];
%inputdata=[];
%outputdata=[];
[fid,msg]=fopen(filename,'rt');
if fid<0
    error('Can not open file');
end
idx=1;
finddata=0;
enddata=0;
idxdata=1;
while 1
    tline = fgets(fid);
    if ~ischar(tline)
        break,
    end  
         %read data
             if idxdata==1
                 tt1=tline;
                 colname=marray_tabassign(tline,1);   %this is for check column names 
                 lncolname=length(colname);
                 repidx=strmatch('Rgn_R',colname);
                 for i=1:length(repidx)
                     if strcmp(colname{repidx(i)},'Rgn_Ratio')~=1
                        colname{repidx(i)}='Rgn_Ratio_squre';
                    end
                 end
                 for i=1:lncolname
                    tempname=strrep(deblank(colname{i}),'._','');
                    tempname=strrep(tempname,' ','_');
                    tempname=strrep(tempname,'.','');
                    tempname=strrep(tempname,'%','Pr');
                    tempname=strrep(tempname,'+','Plus');
                    tempname=strrep(tempname,'-','Minus');
                    tempname=strrep(tempname,'>','Gt');
                    tempname=strrep(tempname,'(',''); %added May 06 2002
                    tempname=strrep(tempname,')','');
                    tempname=strrep(tempname,'/','v');
                    tempname=strrep(tempname,'\','v');
                    tempname=strrep(tempname,'?','');
                    tempname=strrep(tempname,'"','');
                    tempname=strrep(tempname,',','');
                    tempname=strrep(tempname,'=','eq');
                    tempname=strrep(tempname,'#','NO');
                    tempname=strrep(tempname,'R²','R2'); %added aug 2006
		    tempname=strrep(tempname,'<','Ls'); %added aug 2006
		    tempname=strrep(tempname,':','_'); %added aug 2006

		    colname{i}=tempname;
                 end
                tempdata2=cell(1,46000);
                tempdata2{1}=tline;
                temp=cell(46000,lncolname);
                 %make input format %this is not so big imporvements
                 %Added Wang 29/01/02
                 %str_inform=[ repmat('%s',[1 lncolname])];
                 %str_outform=cellstr([repmat('g',lncolname,1) strjust(num2str((1:lncolname)'),'left')  repmat(',',lncolname,1) ]);
                 %str_outform(lncolname)=strrep(str_outform(lncolname),',','');
                 %str_outform=strvcat(str_outform)';
                 %str11=['[' , reshape(str_outform,1,size(str_outform,1)*size(str_outform,2)) ']' ];
                %str_load=[ str11 '=strread(tline,', '''', str_inform,'''',',','''delimiter''',',''\t\n'',','''whitespace''',',','''''' ');'];
             else
                 tempdata2{idxdata-1}=tline;
                 %eval(str_load);
                 %eval(['varcol='str11 ';']);
                 varcol=marray_tabassign_harbison(tline,lncolname);
                 temp(idxdata-1,:)=varcol(:);
             end
            idxdata=idxdata+1;
end
fclose(fid);

for j=1:lncolname
    
     tempname=strvcat(colname{j});
     eval(['inputdata.',tempname,'=temp(1:idxdata-idx-1,j);']);
end
idx_ID=strmatch('ID',colname);
if isempty(idx_ID)
    inputdata.ID=[];
end
tt=etime(clock,t0);
