function result=mcgh_repData(inputdata)
    inputdata=strrep(inputdata,'jan','1');
    inputdata=strrep(inputdata,'feb','2');
    inputdata=strrep(inputdata,'mar','3');
    inputdata=strrep(inputdata,'apr','4');
    inputdata=strrep(inputdata,'may','5');
    inputdata=strrep(inputdata,'jun','6');
    inputdata=strrep(inputdata,'jul','7');
    inputdata=strrep(inputdata,'aug','8');
    inputdata=strrep(inputdata,'sep','9');
    inputdata=strrep(inputdata,'oct','10');
    inputdata=strrep(inputdata,'nov','11');
    inputdata=strrep(inputdata,'dec','12');
    result=inputdata;
   