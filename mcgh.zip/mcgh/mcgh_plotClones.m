function mcgh_plotClones(sorteddata,IA,IB,mean1,std1,final_name1,final_ratio1,final_std1,sorteddata3,colname3)
%filename='Sorted_clones1.txt'
%filename=clone_location_filename;
%[sorteddata,colname]=marray_testload_marray(filename);
%figure
%A=lower(sorteddata.BAC_PAC);
%B=lower(final_name1);
%[C IA IB]=intersect(A,B);
global numofrun chrom_rang xtick_labels xtick_locations iserrorBar isAmpPlot inter_value ismcgh2

%added 2005 plot color labesl
if ~isempty (sorteddata3) & ~isempty(colname3)
   eval(['all_color_type=sorteddata3.',strvcat(colname3(2)),';']);
   color_type=unique(all_color_type);
   eval(['color_clone_name=sorteddata3.',strvcat(colname3(1)),';']);
   num_of_color_type=length(color_type) ; 
end    
%end added    
Genom_position=str2num(strvcat(sorteddata.Order_Number(IA)));
%[uniq_position idx_uniq]=unique(Genom_position);
%added 10.03.2003
[uniq_position idx_uniq]=sort(Genom_position);
%idx_uniq=1:length(Genom_position);

Chor=(strvcat(sorteddata.Chorsmor(IA)));
uniq_Chor=Chor(idx_uniq,:);

%found duplicated position
t1=idx_uniq;
t2=1:length(Genom_position);
tt=ismember(t2,t1);
duplicated_idx=find(tt==0);
%size(Genom_position)

if numofrun<1
    marray_debuge(['Duplicated positoins ..', num2str(Genom_position(duplicated_idx))]);
    marray_debuge(['The number of total clones is ', num2str(length(uniq_position))]);
end

copy_number=final_ratio1(IB);
copy_number_std=final_std1(IB);

uniq_copy_number=copy_number(idx_uniq);
uniq_copy_number_std=copy_number_std(idx_uniq);
if iserrorBar==1
    errorbar(uniq_position,uniq_copy_number,uniq_copy_number_std,'.');
else
    plot(uniq_position,uniq_copy_number,'.');
    if ~isempty(sorteddata3) & ~isempty(colname3)
        copy_number_name=final_name1(IB);
        uniq_copy_number_name=copy_number_name(idx_uniq);
        color_point=['r.';'g.';'y.';'c.';'k^'];
        color_string={'red','green','yellow','cyan','black'};
        for ci=1:num_of_color_type
            label_idx=strmatch(color_type(ci),all_color_type,'row');
            label_name=color_clone_name(label_idx);
            %[size(label_idx), size(uniq_copy_number_name), size(label_name)]
            %uniq_copy_number_name(1:10)
            %label_name(1:10)
            [labels_name,label_uniq_idx1,label_uniq_idx2]=intersect(cellstr(lower(uniq_copy_number_name)),lower(label_name),'row');
           % size(uniq_position),size(uniq_copy_number)
            label_x=uniq_position(label_uniq_idx1,:);
            label_y=uniq_copy_number(label_uniq_idx1,:);
            %size(label_uniq_idx1)
            hold on;
            plot(label_x,label_y,color_point(ci,:));  
            marray_debuge([strvcat(color_type(ci)), ' is ', strvcat(color_string(ci)),' color!']);
        end
    end
end

miny=min(copy_number(idx_uniq));%final_ratio1(IB));
maxy=max(copy_number(idx_uniq));%final_ratio1(IB));
lnx=max(max(uniq_position));
min_x=min(min(uniq_position));
%plot(IA,final_ratio1(IB),'.');
%cl=sorteddata.Chorsmor;
%added june2004
if ismcgh2==1
    cl=str2num(deblank(strvcat(uniq_Chor)));
else
    cl=uniq_Chor;
end
if numofrun<1
    idx=0;
    for i=1:27
        temp_t=[];
        t=[];
        %t=find(str2num(strvcat(cl))==i);
        if ismcgh2==1
            temp_t=find(cl==i);
            %added 12.17.2003
            %added june2004
        else
            temp_t=strmatch(num2str(i),cl,'exact');
        end 
         t=uniq_position(temp_t);
        %pause
        if (~isempty(t))
            hold on;
            plot([max(t) max(t)],[ceil(miny-1) ceil(maxy)],'r-');
            idx=idx+1;
            chrom_rang(idx)=max(t);
            if i==23
                xtick_labels(idx)={'X'};
            elseif i==24
                xtick_labels(idx)={'Y'};
            elseif i==25
                 xtick_labels(idx)={'OneQ'};    
            elseif i==26
                 xtick_labels(idx)={'OncoBAC'};
            elseif i==27
                 xtick_labels(idx)={'Extra'};
            else
                xtick_labels(idx)={num2str(i)};
            end
             xtick_locations(idx)=median(t);
            %raw_locations(idx)=max(t);
            %if idx-1>0
            %    xtick_locations(idx)=(max(t)-raw_locations(idx-1))/2+raw_locations(idx-1);
            %else
           %         xtick_locations(idx)=max(t)/2;   
           % end
        else
            if i==23
                temp_t=strmatch('X',upper(cl),'exact');
                t=uniq_position(temp_t);
            elseif i==24
                temp_t=strmatch('Y',upper(cl),'exact');
                t=uniq_position(temp_t);
            elseif i==25
                temp_t=strmatch('OneQ',cl,'exact');
                t=uniq_position(temp_t);
            elseif i==26
                temp_t=strmatch('OncoBAC',cl,'exact');
                t=uniq_position(temp_t);
            elseif i==27
                temp_t=strmatch('Extra',cl,'exact');
                t=uniq_position(temp_t);
            end
            hold on;
            if (~isempty(t))
                plot([max(t) max(t)],[ceil(miny-1) ceil(maxy)],'r-');
                idx=idx+1;
                chrom_rang(idx)=max(t);
                if i==23
                    xtick_labels(idx)={'X'};
                elseif i==24
                    xtick_labels(idx)={'Y'};
                elseif i==25
                    xtick_labels(idx)={'OneQ'};    
                elseif i==26
                    xtick_labels(idx)={'OncoBAC'};
                elseif i==27
                    xtick_labels(idx)={'Extra'};
                else
                    xtick_labels(idx)={num2str(i)};
                end
                 xtick_locations(idx)=median(t);
                %raw_locations(idx)=max(t);
                %if idx-1>0
                %    xtick_locations(idx)=(max(t)-raw_locations(idx-1))/2+raw_locations(idx-1);
                %else
               %     xtick_locations(idx)=max(t)/2;   
               %end
            end
        end
    end
else
  lnofline=length(chrom_rang);
  hold on;
  plot(repmat(chrom_rang,2,1), repmat([ceil(miny-1) ceil(maxy)],lnofline,1)','r-');
end %end if

%sort xticks
[sorted_x_location sorted_idx_x]=sort(xtick_locations);
xtick_labels=xtick_labels(sorted_idx_x);
xtick_locations=xtick_locations(sorted_idx_x);

%mean1=-0.1;
%std1=0.2;
hold on
%lnx=length(cl);
%pL1=plot(1:100:lnx,mean1,'-k','LineWidth',2);
pL1=line([1,lnx],[mean1, mean1]);

hold on
%pL2=plot(1:100:lnx,mean1+3*std1,'-k','LineWidth',2);
pL2=line([1,lnx],[mean1+3*std1,mean1+3*std1]);

hold on
%pL3=plot(1:100:lnx,mean1-3*std1,'-k','LineWidth',2);
pL3=line([1,lnx],[mean1-3*std1,mean1-3*std1]);

%plot ampl boundary
%hold on
%[sorted_x ,sorted_y]=mcgh_fit_amplBoundary(final_ratio1,IA,IB);
if (inter_value ~=0 & isAmpPlot==1)
    %type 1 amplicon boundaries
    %[sorted_x ,sorted_y]=mcgh_FitAmplBoundary(final_ratio1(IB),Genom_position);
    
    %type 2 amplicon boundaries
    %[sorted_x idx_x]=sort(uniq_position);
    %sorted_y=uniq_copy_number(idx_x);
    %yd=wden(sorted_y,'heursure','s','one',ceil(inter_value),'rbio1.1');
    
    %type 3 amplicon boundaries
    [sorted_x idx_x]=sort(uniq_position);
    sorted_y=uniq_copy_number(idx_x);
    N=length(sorted_y);
    max_D=ceil(log(N)/log(2));
    new_N=2^max_D;
    min_x=sorted_x(1);
    max_x=sorted_x(end);
    intervalue=(max_x-min_x)/(new_N-1);
    new_x=min_x:intervalue:max_x;
    %added junbai
    [uniq_sorted_x,uniq_sorted_x_idx]=unique(sorted_x);
    uniq_sorted_y=sorted_y(uniq_sorted_x_idx);
    %end added
    new_y=interp1(uniq_sorted_x,uniq_sorted_y,new_x,'nearest');
    qmf8=MakeONFilter('Haar',8);
    D_level=ceil(inter_value);
    if D_level<=max_D
        %SURE, Visu
        [yd, wcoef]  = WaveShrink(new_y,'Visu',D_level,qmf8); 
        sorted_x=[];
        sorted_x=new_x;
    else
        [yd, wcoef]  = WaveShrink(new_y,'Visu',4,qmf8); 
        sorted_x=[];
        sorted_x=new_x;
        errordlg(['Window size is too big, please try window size less than ', num2str(max_D)]);
    end
    
    hold on;
    plot(sorted_x,yd,'m-','linewidth',1.5);
elseif (inter_value ~=0 & isAmpPlot==2)
    %type 1 amplicon boundaries
    [sorted_x ,sorted_y]=mcgh_FitAmplBoundary(final_ratio1(IB),Genom_position);
     hold on;
    plot(sorted_x,sorted_y,'m-','linewidth',1.5)
end



%axis([0 lnx miny maxy]);
axis([min_x lnx ceil(miny-1) ceil(maxy)])

set(gca,'TickLength',[0,0]);
set(gca,'GridLineStyle','-');
%set(gca,'Xcolor',[0.7 0.7 0.8]);
%set(gca,'Ycolor',[1 0 1]);
set(gca,'Ycolor',[0 0 0]);
set(gca,'Color',[0.7 0.7 0.8]);
grid off
set(get(gca,'Children'),'ButtonDownFcn','mcgh_slctPoint');
xl=xlabel('Chromosome location');
yl=ylabel('Relative copy number (log2)');
set(xl,'Color',[0 0 0],'FontSize',13);
set(yl,'Color',[0 0 0 ],'FontSize',13);
%xtick_locations
[xtick_locations xt_i]=sort(xtick_locations);
set(gca,'XTick',xtick_locations,'FontSize',6);
set(gca,'XtickLabel',xtick_labels(xt_i));
temp_yt=get(gca,'YTick');
xt=get(gca,'XTick');
set(gca,'FontSize',10);

%start draw horizen lines
if length(temp_yt)<4
    max_yt=ceil(max(temp_yt));
    min_yt=ceil(min(temp_yt));
    yt(1)=min_yt;
    yt(2)=min_yt/abs(min_yt)*ceil(abs(min_yt)/2);
    yt(3)=0;
    yt(4)=ceil(max_yt/2);
    yt(5)=max_yt;
    set(gca,'Ytick',yt);
    set(gca,'YtickLabel',cellstr(num2str(yt')));
else
    yt=temp_yt;
end

for j=1:length(yt)
    xx=0:ceil(lnx/100):lnx;
    yy=repmat(yt(j),1,length(xx));
    ln=line(xx,yy);
    %set(ln,'Color',[ 1 0 1]);
    set(ln,'Color',[0 0 0]);
end
%showone;
set(pL1,'Color',[0 1 0]);
set(pL1,'LineWidth',2);
set(pL2,'Color',[0 1 0]);
set(pL2,'LineWidth',2);
set(pL3,'Color',[0 1 0]);
set(pL3,'LineWidth',2);




%figure
%A=lower(sorteddata.BAC_PAC);
%B=lower(final_name2);
%[C IA IB]=intersect(A,B)
%errorbar(IA,final_ratio2(IB),final_std2(IB),'.')
%cl=sorteddata.Chorsmor;
%for i=1:23
%  t=find(str2num(strvcat(cl))==i);
%  if ~isempty(t)
%    hold on;
%    plot([max(t) max(t)],[-2 5],'r-')
%  end
%end
%mean2=0.08;
%std2=0.15;
%plot(1:350,mean2,'k-')
%hold on
%plot(1:450,mean2+3*std2,'k-');
%hold on
%plot(1:450,mean2-3*std2,'k-');
%axis([1 350 -2 5]);
%A={ 'a' ,'d', 'c', 'f', 'g', 'h', 'b', 'e'}
%B={ 'b' ,'c' ,'d' ,'g' ,'h'}
%[C IA IB ]= intersect(A,B)
