function mcgh_plotFindClone(find_cloneString)
global outdata varnames findClone_fig F1

copy_numberChanges=outdata(:,1);
clone_location=outdata(:,end);
clone_names=lower(deblank(varnames));
match_idx=strmatch(lower(find_cloneString),clone_names,'exect');
if ~isempty(match_idx)
    tempratio=copy_numberChanges(match_idx);
    templocation=clone_location(match_idx);
    set(findClone_fig,'HandleVisibility','on');
    figure(findClone_fig);
    uicontrol('style','text','string',...
    cellstr(['Name: ',strvcat(find_cloneString),', Ratio: ',num2str(tempratio), ', Location: ', num2str(templocation) ]), ...
    'Units','normalized','position',[.4 .4  .5 0.3],...
    'Backg', [1 1 1],...
    'Foreg', [0 0 0],'FontWeight','bold');
    set(findClone_fig,'HandleVisibility','off');

    figure(F1);
    hold on
    subplot(2,1,2);
    plot(templocation,tempratio,'yo');
else
    errordlg('Not found! Please try again');
end

