function [cond, newdata,newdata_intensity,q_com,q_com1,q_com2,idxq_com,rep_flag1,rep_flag2,minIntensity_ch1,minIntensity_ch2]...
    =mcgh_SfilterBad(data,ref1or2,normtype,figno,alpha,ch1_int,ch2_int,ch1_intUser,ch2_intUser)
global stdBackIn filter_chanel
%marray_SfilterBad, filering weak spots then apply different methods to normalize the ratios
%Input:
%data is the output results from marray_testload_Quant or marray_testload_GenPix
%ref1or2=1 compute ratio=channel 2/channel 1; ref1or2=2 compute reatio=channel 1/channel 2
%normtype=1 is simple normalization, normtype=2 is intensity dependent normalization
%figno is the figure number
%alpha is the parameter for signal-to-noise ratio
%(Signal-Background)/(Background+2*Background_STD)>alpha
%
%ch1_int=ch2_int=1 Minum(Intensity -Background Intensity)> 0
%ch1_int=ch2_int=2 Minum(Intensity -Background Intensity)>= median(bk+2*bk_std)
%ch1_int=ch2_int=3 Minum(Intensity -Background Intensity)>= Intensity_UserDefine./median(bk+2*bk_std)
%ch1_intUser is channel 1 Intensity_UserDefine
%ch2_intUser is channel 2 Intensity_UserDefine
%

%Example
%Fliter Bad measurement from Excel Export file
% Int/(Int_Bg+2*Int_BgSDV)> 0.65 and Int >0;
% ratio= Ch2_In/Ch1_In
%part 1 assign input data.
global table 
warning off;
ch1=str2num(strvcat(data.ch1_Intensity))+10;
ch1_bg=str2num(strvcat(data.ch1_Background))+10; %plus 10 for avoid zeros
ch1_bgSDV=str2num(strvcat(data.ch1_Background_Std_Dev));
ignorflag=str2num(strvcat(data.Ignore_Filter));
%size(ignorflag)

name=data.Name;

ch2=str2num(strvcat(data.ch2_Intensity))+10;
ch2_bg=str2num(strvcat(data.ch2_Background))+10;
ch2_bgSDV=str2num(strvcat(data.ch2_Background_Std_Dev));

%part 2 find empty spots
idxempty=strmatch('empty',lower(name));
idxblank=strmatch('-',lower(name));
idxnull=strmatch('null',lower(name));
idxna=strmatch('na',lower(name),'exact');
idxunknown=strmatch('unknown',lower(name)); %it's possibile other character means empty spots
                                    %but we should force it has a standard !!
idxnone=strmatch('none',lower(name));
idxfail=strmatch('failed',lower(name));
qualtScore=ignorflag; %quality score, 0 is minimumm, 1 is maximum assign manually falgged 
                      % spots's quality is zero
qualtScore(idxempty,:)=0;  %assign zero to empty spots.
qualtScore(idxblank,:)=0;
qualtScore(idxunknown,:)=0; %these spots should have quality score =0;!!
qualtScore(idxnull,:)=0;
qualtScore(idxnone,:)=0;
qualtScore(idxfail,:)=0;
qualtScore(idxna,:)=0;
%size(qualtScore)

%part 3 Calibration of each channel's intensity.
%find all spots, without flaged and empty ones
idxgood=find(qualtScore~=0);
idxnonempty=idxgood;
numofSpots=length(data.Row);
marray_debuge(['Total number of Spots :', num2str(numofSpots)]);
marray_debuge(['Number of empty and flagged spots :',num2str(numofSpots-size(idxgood,1))]);
marray_debuge(['Those spots will not included in further data analysis!']);

%find median background signal intensity of Ch1 and Ch2
%added June 2005
if stdBackIn<7
%with std Back
	minIntensity_ch1=median(ch1_bg(idxgood)+(stdBackIn-1).*ch1_bgSDV(idxgood));
	minIntensity_ch2=median(ch2_bg(idxgood)+(stdBackIn-1).*ch2_bgSDV(idxgood));
	marray_debuge(['Median(Background_Int +',num2str(stdBackIn-1),'*Background_IntSDV) in Ch1=',...
        	num2str(minIntensity_ch1),'; Ch2=',num2str(minIntensity_ch2)]);
else
%without std Back
	minIntensity_ch1=(stdBackIn-6)*median(ch1_bg(idxgood)+(1-1).*ch1_bgSDV(idxgood));
        minIntensity_ch2=(stdBackIn-6)*median(ch2_bg(idxgood)+(1-1).*ch2_bgSDV(idxgood));
        marray_debuge([num2str(stdBackIn-6)  '*Median(Background_Int) in Ch1=',...
                num2str(minIntensity_ch1),'; Ch2=',num2str(minIntensity_ch2)]);
end


%added july04
Cab_ch1=ch1./minIntensity_ch1;
Cab_ch2=ch2./minIntensity_ch2;
Cab_ch1_bg=ch1_bg./minIntensity_ch1;
Cab_ch2_bg=ch2_bg./minIntensity_ch2;

%size(ch2_bg),size(ch2_bgSDV),size(minIntensity_ch2)

%Cab_ch1_bg_2std=(ch1_bg+2.*ch1_bgSDV)./minIntensity_ch1;
%Cab_ch2_bg_2std=(ch2_bg+2.*ch2_bgSDV)./minIntensity_ch2;
%%end added

%find spots's calibrated intensity small than alpha;
%idx_ch1weak=find(Cab_ch1(idxgood)<alpha);
%idx_ch2weak=find(Cab_ch2(idxgood)<alpha);
%tmp_qualt=qualtScore(idxgood);
%tmp_qualt(idx_ch1weak)=0;
%tmp_qualt(idx_ch2weak)=0;
%qualtScore(idxgood)=tmp_qualt;

%part 3 substract background intensity from each spots
%this part have BUG !!! 2001.04.24
%add July 2004
ch1_redsub=(ch1-ch1_bg);  %not include flaged and empty spots
ch2_greensub=(ch2-ch2_bg);
%added june 2005
if stdBackIn<7
	Cab_ch1_bg_2std=(ch1_bg+(stdBackIn-1).*ch1_bgSDV);
	Cab_ch2_bg_2std=(ch2_bg+(stdBackIn-1).*ch2_bgSDV);
else
	Cab_ch1_bg_2std=(stdBackIn-6)*(ch1_bg+(1-1).*ch1_bgSDV);
        Cab_ch2_bg_2std=(stdBackIn-6)*(ch2_bg+(1-1).*ch2_bgSDV);
end

%end added

% disp('Filtering type 3 BSS');
   %negative value have to fix ?? 10/30 2001
   % flaged_red=ones(size(ch1_redsub));
   % flaged_green=flaged_red;
    
   if (ch1_int==1 & ch2_int==1) %default
     cond1=(Cab_ch1_bg>=0 & Cab_ch2_bg>=0 & Cab_ch1>0 & Cab_ch2>0 & ch1_redsub>0 & ch2_greensub>0 );
      marray_debuge('Minum (Intensity -Background Intensity)> 0');
   elseif (ch1_int==2 & ch2_int==2)
      cond1=(Cab_ch1_bg>=0 & Cab_ch2_bg>=0 & Cab_ch1>0 & Cab_ch2>0 & ch1_redsub>=1 & ch2_greensub>=1 );
      marray_debuge('Minum (Intensity -Background Intensity)>= median(bk+2*bk_std)');
   elseif (ch1_int==3 & ch2_int==3)
       cond1=(Cab_ch1_bg>=0 & Cab_ch2_bg>=0 & Cab_ch1>0 & Cab_ch2>0 & ch1_redsub>=ch1_intUser./minIntensity_ch1 ...
           & ch2_greensub>=ch2_intUser./minIntensity_ch2 );
	%added june 2005 
	if stdBackIn<7	
       		marray_debuge('Minum (Intensity -Background Intensity)>= Intensity_UserDefine./median(bk+',num2str(stdBackIn-1),'*bk_std)');
     	else
		 marray_debuge('Minum (Intensity -Background Intensity)>= Intensity_UserDefine./',num2str(stdBackIn-6),'/median(bk)');
	end
		  marray_debuge(['Minum ch1:' num2str(ch1_intUser), '->',num2str(ch1_intUser./minIntensity_ch1),...
               ' ch2:' num2str(ch2_intUser),'->',num2str(ch2_intUser./minIntensity_ch2)] );
   else 
       error('Go back to check your Marray Properties, select the right minum intensity');
       stop;
   end
       
    %idxng_red=find(ch1_redsub < 0  | ch1_redsub==0 );
    %idxng_green=find(ch2_greensub<0 | ch2_greensub==0);
    %flaged_red(idxng_red)=0;
    %flaged_green(idxng_green)=0;
    %ch2_redsub(idxng_red)=ones(size(idxng_red));
    %ch2_greensub(idxng_green)=minIntensityGreen.*ones(size(idxng_green));
  
    %cond2=(Cab_ch1>=alpha & Cab_ch2>=alpha);  %%%NOTE temp changed in 11/30 by wang
    %cond3=(Cab_ch1>=alpha & Cab_ch2<alpha);
    %cond4=(Cab_ch2>=alpha & Cab_ch1<alpha) ;
    
    cond2=(ch1_redsub./Cab_ch1_bg_2std>=1 & ch2_greensub./Cab_ch2_bg_2std>=1);
    cond3=(ch1_redsub./Cab_ch1_bg_2std>=1 & ch2_greensub./Cab_ch2_bg_2std<1);
    cond4=(ch1_redsub./Cab_ch1_bg_2std<1 & ch2_greensub./Cab_ch2_bg_2std>=1);
   
    if stdBackIn<7  
    	marray_debuge(['(Intensity-Back)/(bk+',num2str(stdBackIn-1),'*bk_std)>=' num2str(1)] );
    else
	marray_debuge(['(Intensity-Back)/bk/',num2str(stdBackIn-6),'>=' num2str(1)] );
    end
    cond7= (cond1==1 & cond3==1 );
    cond8= (cond1==1 & cond4==1 );
    cond22= (cond1==1 & cond2==1);
    %changed July 2004
    if filter_chanel==1
        cond= ( cond22 | cond7==1 | cond8==1) ;
	marray_debuge(['Single channel filtering ....!']);
    else
        cond=cond22;
	marray_debuge(['Double channel filtering ...!']);
    end
    %end change
       
    %size(find(cond==0))
    %size(find(cond.*qualtScore==0))
    
    cond=cond.*qualtScore; %replace ignored spot as zero;
    %size(find(cond==0),1)
    marray_debuge(['Total filtering ', num2str( size(find(cond==0),1) ), ' spots! ']);   
    cond2=[cond,cond];

    filtered_redsub=cond.*ch1_redsub;
    filtered_greensub=cond.*ch2_greensub;
    sumch1_redsub=sum(filtered_redsub); % not include bad spots and flaged spots in Normalizations
    sumch2_greensub=sum(filtered_greensub);
%%%%%%%%%%%%%%%%%%%%%%%%%%%
idxq_com=cond;

%type1
if normtype==1
    marray_debuge('Simple normalization');
   
	[ch2_ratio_normed,ch2_intensity_normed]=marray_Snorm_type1( ...
   filtered_redsub,filtered_greensub,sumch1_redsub,sumch2_greensub,ref1or2,figno,idxq_com);
	ch2_ratio=ch2_ratio_normed;
	ch2_intensity=ch2_intensity_normed;
    
    filtered_ratio=cond2.*ch2_ratio;
	newdata=filtered_ratio;
   newdata_intensity=cond2.*ch2_intensity;
elseif normtype==2
%type2
marray_debuge('Intensity dependent normalization')
 
	[ch2_ratio_normed,ch2_intensity_normed]=mcgh_Snorm_type2( ...
   filtered_redsub,filtered_greensub,sumch1_redsub,sumch2_greensub,ref1or2,figno,idxq_com);
    ch2_ratio=ch2_ratio_normed;
	ch2_intensity=ch2_intensity_normed;
	filtered_ratio=cond2.*ch2_ratio;
	newdata=filtered_ratio;
	newdata_intensity=cond2.*ch2_intensity;
elseif normtype==3
    %%print position normalization
     marray_debuge('Print position normalization');
   
	[ch2_ratio_normed,ch2_intensity_normed]=mcgh_Snorm_type3( ...
    filtered_redsub,filtered_greensub,sumch1_redsub,sumch2_greensub,ref1or2,figno,idxq_com,data);
	ch2_ratio=ch2_ratio_normed;
	ch2_intensity=ch2_intensity_normed;
    
    filtered_ratio=cond2.*ch2_ratio;
	newdata=filtered_ratio;
    newdata_intensity=cond2.*ch2_intensity;

    
end

q_com=zeros(size(qualtScore));
q_com1=q_com;
q_com2=q_com;
rep_flag1=q_com;
rep_flag2=q_com;
