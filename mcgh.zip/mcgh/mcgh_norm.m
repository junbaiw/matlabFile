function [filtered_name1, norm_ratio1]=mcgh_norm(inputdata1,cond1,filtered_redsub1,filtered_greensub1)
%normalized ratio to median of raw ratio

filtered_name1=inputdata1.Name(cond1==1,:);
filtered_subch1= filtered_redsub1(cond1==1,:);  %red
filtered_subch2= filtered_greensub1(cond1==1,:); %green
raw_ratio1=filtered_subch2./filtered_subch1;  %ratio is Ch2/Ch1
media_of_raw=median(raw_ratio1);
norm_ratio1=raw_ratio1./media_of_raw;
marray_debuge('Ratio=Ch2_bkSub / Ch1_bkSub');
marray_debuge('Noramlize the ratio based on the median of overall raw ratio');
marray_debuge(['Normalized factor equals: ', num2str(media_of_raw)]);
