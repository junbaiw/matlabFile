function [final_name , final_Clocat,final_ratio, final_std, final_numofdup]=mcgh_meanFull(f_name1,f_Clocat,log2_norm1)
A=f_name1;
C=log2_norm1;
[B i j ]=unique(A);
D=f_Clocat(i);
idx=1;
id=1;
max_std=2;
for ri=1:length(i)
    temp_name=B{ri};
    temp_Clocat=D{ri};
    idx_duplicated=find(j==ri);
    temp_ratio=C(idx_duplicated);
    temp_mean=mean(temp_ratio);
    temp_std=std(temp_ratio);
    lendup=length(idx_duplicated);
    if lendup>1 & temp_std<max_std
        final_name{idx}=temp_name;
        final_Clocat{idx}=temp_Clocat;
        final_ratio(idx)=temp_mean;
        final_std(idx)=temp_std;
        final_numofdup(idx)=lendup;
        idx=idx+1;
    else
       
        %pause
        %temp_ratio
        %temp_std
        %disp('Select spot to delete :');
        delet_name{id}=temp_name;
        id=id+1;
    end
end
marray_debuge(['Delete ',num2str(id-1), ' clones with standard deviation > = ', num2str(max_std)]);   
