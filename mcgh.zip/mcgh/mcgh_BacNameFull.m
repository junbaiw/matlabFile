function [f_name, f_Clocat]=mcgh_BacNameFull(len,filtered_name1)
for i=1:len
    temp=strvcat(filtered_name1(i,:));
    idx=findstr('_',temp);
    if ~isempty(idx)
       f_name{i}=temp(1:idx(1)-1);
       f_Clocat{i}=temp(idx(1):end);
    else
        f_name{i}=temp;
        f_Clocat{i}='_';
    end
end
