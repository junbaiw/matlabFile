global  htxt_exportFiles
global fileform inter_value normtype clone_file_path
global stdBackIn maxStd_rep
global p_1 p1 p0 m1 m0 m_1 s_1 s1 s0
global str1 F1
global numofrun

[filename, pathname] = uigetfile('*.*', 'Select File Path ...');
if length(filename)==1 & length(pathname)==1 & filename==0 & pathname==0
    break;
else
    eval(['cd ' ,pathname,';'])
    pstring={['Select MCGH Export files (*.*OUT) from : ',pathname]};
    d = dir;
    str = {d.name};
    [s,v] = listdlg('PromptString',pstring,'SelectionMode','multiple',...
                'ListString',str,'ListSize',[400 300]);
    selected_files=str(s);
    sel_files=setdiff(selected_files,'.');
    lnfile=length(sel_files);
    if lnfile>=1
        mmcgh_dispfiles(sel_files,lnfile,v,pathname);
    end
end