function mcgh_clone2web(cloneName)
%global genecell ind1 filename3
%http://www.ensembl.org/Homo_sapiens/textview?species=All&idx=All&q=dj20n18&x=1&y=12
    % current cell is 1 genename 2 clone 3 plate 4 NCI-LCaddr 5-7 address(F R C)
clne     = strvcat(cloneName);
url     = ['http://www.ensembl.org/Homo_sapiens/textview?species=All&idx=All&q=',clne,'&x=1&y=12'];
web(url,'-browser');
%if ~isunix
%    www_str=['!C:\Program\'' Files\','Netscape\Netscape\Netscp'' "',url,'"'];
%    eval(www_str);
%else
%    www_str=['!netscape ','',url,''];
%    eval(www_str);
%end

