function [id,name]=marray_Separate_ID_Name(Name_data,numofSpots)
%separate ID and name from string, only for QuantArray
%
for i=1:numofSpots 
    tempname=Name_data{i};
    %added jbw 12/|0/01
    tempid=findstr(tempname,'_');
    lntemp=length(tempname);
  if isempty(tempid)
      if isnan(str2double(tempname)) % check ID or Name  
         name{i}=lower(tempname);
         id{i}=lower('empty');
      else
         name{i}=lower('empty');
         id{i}=lower(tempname);
      end
  else
      imagenum=lower(deblank(tempname(1:tempid(1)-1)));
      if isnan(str2double(imagenum))
        id{i}=lower('empty');
        name{i}=lower(tempname);
      else
         id{i}=imagenum;
         name{i}=lower(deblank(tempname(tempid(1)+1:lntemp)));
     end
  end
end
