function [results, id]=marray_searchlog2(newx,newy,x,y,oldInt,Z,name,di);
global htxt2 genecell2 ind1 filename3 file1 newq_score1 newq_score2 
%search in Vector x,find
% correlated Z strings for (newx)
%
%Added 27/06/01
%meanx=real(x+y)/2;
%meanx=real(sqrt((oldInt(:,1).*oldInt(:,2)+oldInt(:,3).*oldInt(:,4))./2));

  %if islog2~=2
  meanx=real(((oldInt(:,1).*oldInt(:,2)+oldInt(:,3).*oldInt(:,4))./2).^(1/3));
  %elseif islog2==2
  %meanx=real(((oldInt(:,1).*oldInt(:,2)+oldInt(:,3).*oldInt(:,4))./2));
  %end
%added 10/08/01
delty=real(x-y);
%delty=di;

%delty=var([x,y]')';
%delty=real(x./median(x)-y./median(y));

xlimit=abs(meanx-newx*ones(size(meanx)))./abs(meanx);
ylimit=abs(delty-newy*ones(size(delty)))./abs(delty);
limit=0.05;
[minvalue id] =min(xlimit+ylimit);
isfound=minvalue<=limit;
idx2=find(isfound==1);
if ~isempty(idx2)
  colid=char(Z(id(idx2),:));
  namestr=char(name(id(idx2),:));
  
  %Added JBW
  tempID=char(Z(id,:));
  tempGname=char(name(id,:));
  
  ratx=real(x(id(idx2)));
  raty=real(y(id(idx2)));
  dix=di(id(idx2));
  q_score1=newq_score1(id(idx2));
  q_score2=newq_score2(id(idx2));
  n=length(id(idx2));
  for i=1:n
      temp=colid(i,:);
      tempname=namestr(i,:);
      lineIndex=marray_findlinefeed(temp);
      tabIndex=marray_findtab(temp);
      ntabIndex=marray_findtab(tempname) ; 
      if isempty(lineIndex) ~=1 
        temp=temp(lineIndex+1:length(temp));
      end
      if isempty(tabIndex)~=1
         temp=temp(1:tabIndex-1);
      end
      if isempty(ntabIndex)~=1 & length(ntabIndex)>1
         tempname=tempname(1:ntabIndex(2)-1);   
      end;
      %tempid=findstr(tempname,' '); %changed 12/07/01
      tempid=findstr(tempname,'_');
      lntemp=length(tempname);
      if isempty(tempid)
      name=tempname;
      id=tempname;
    else
      id=deblank(tempname(1:tempid(1)-1));
      name=deblank(tempname(tempid(1)+1:lntemp));
    end
      lnname=length(name);
      if lnname>30
        name=name(1:30);
      end
      %Added JBW
      id=deblank(tempID);
      name=deblank(tempGname);
   
      genecell2={[char(10),' IMAGE:',char(9),id,char(9),' Gene Name: ', name, ...
              char(10),'rat1=',num2str(ratx),', rat2=',num2str(raty),', d(i)=', num2str(dix)]};
               %, ...
              %', Q_com1=',num2str(q_score1), ', Q_com2=',num2str(q_score2) ]};
     ind1=1; %it's for clone2www.
     filename3=file1; %it's for clone2www
      set(htxt2,'String',genecell2);
      %disp([' ColID: ', id, ', Gene Name: ', name]);
     %disp( ['rat1=',num2str(ratx),', rat2=',num2str(raty)]);
  end
  %disp(['              ']);
  %results=[ num2str(n) ,' found' ];      
  %results=temp; %changed 12/07/01
  results=id;
else
   results='None';
end
id=id(idx2); 

