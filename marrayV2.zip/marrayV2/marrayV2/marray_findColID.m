function result=marray_findColID(filename)
%
%filename='Export1710.txtColID.txt'
fid=fopen(filename);
data=fscanf(fid,'%c');
returnIndex=findreturn(data);
lenofreturn=length(returnIndex);
for i=1:lenofreturn
   if i==1
      result{i,1}=data(1:returnIndex(1)-1);
   else
      result{i,1}=data(returnIndex(i-1)+1:returnIndex(i)-1);
   end
end
