function linefeedIndex=marray_findlinefeed(str)
%find the position of tab
linefeedIndex=findstr(str,char(10));
