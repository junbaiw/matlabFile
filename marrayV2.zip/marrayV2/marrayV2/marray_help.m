 if exist('HelpfigNumber')
     if HelpfigNumber~=3335 
     %    delete(HelpfigNumber);
     clear HelpfigNumber;
     end;
 end;
   
HelpfigNumber=3335;
titleStr='Marray Version 2';
[txtHndlList,HelpfigNumber]=marray_comp_help(titleStr,HelpfigNumber);