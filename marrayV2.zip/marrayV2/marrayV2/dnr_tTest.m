function P_tTest=dnr_tTest(for_Rate,rev_Rate)
%two size t_test of two groups mean
%input data format n X m
%Input
%n : row is the number of subject need t-test
%m : column is the number of samples in each group
%Output
%P_tTest format n X 1
%is the P value for each row
%
[row1 col1]=size(for_Rate);
[row2 col2]=size(rev_Rate);
m1=mean(for_Rate,2);
m2=mean(rev_Rate,2);
std1=std(for_Rate')';
std2=std(rev_Rate')';
n1=col1;
n2=col2;
s_square=((n1-1).*std1.^2+(n2-1).*std2.^2)./(n1+n2-2);
std_error=sqrt(s_square)*sqrt(1/n1+1/n2);
dFree=n1+n2-2;
t_test=(m1-m2)./std_error;
P_tTest=marray_studT(t_test,dFree);
