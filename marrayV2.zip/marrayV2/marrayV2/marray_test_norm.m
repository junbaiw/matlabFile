function [t,i,nt]=marray_test_norm(tmp_di,idx_di,x,y,newintensity,islog2,surf_fig2,min_ch11,min_ch12,min_ch21,min_ch22);

%load MFH1704Export.txtData.txt;
%load exportjmb1240401Data.txt;
%data1=MFH1704Export;
%data2=exportjmb1240401Data;
%x1=log2(data1(:,16));
%x2=log2(data2(:,16));
%norm plot of the varience of log2 ratio
%if islog==1
%	delt=real(x-y);
%	meanxy=real(x+y)/2;
%else
%   delt=real(log2(x)-log2(y));
%	meanxy=real((log2(x)+log2(y))/2);
%end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%added jbw 10/08/01
delt=real(x-y);
%delt=tmp_di;

%delt=var([x,y]')';
%delt=real(x./median(x)-y./median(y));

%Added 27/06/2001
meanxy=real(x+y)/2;
%meanInt=real(sqrt((newintensity(:,1).*newintensity(:,2)+newintensity(:,3).*newintensity(:,4))./2));
%if islog2~=2
  meanInt=real(((newintensity(:,1).*newintensity(:,2)+newintensity(:,3).*newintensity(:,4))./2).^(1/3));
  min_meanInt=real(((1*1+1*1)./2).^(1/3));
  %elseif islog2==2
%  meanInt=real(((newintensity(:,1).*newintensity(:,2)+newintensity(:,3).*newintensity(:,4))./2));
%  min_meanInt=real(((1*1+1*1)./2)); %.^(1/3));
%end
  %min_meanInt=real(((min_ch11*min_ch12+min_ch21*min_ch22)./2).^(1/3));


meandelt=mean(delt);
stddelt=std(delt);

%Added 27/06/01
minx=min(meanInt);
maxx=max(meanInt);

miny=min(delt);
maxy=max(delt);
%Added 27/06/01
linex=meanInt;

liney=ones(size(linex))*meandelt;
liney2std=liney+2*stddelt;
liney2std2=liney-2*stddelt;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Confidence Interval for bias (mean difference), lower limit and upper limit
%
n=length(delt);
stderror=stddelt./sqrt(n);
stderror2SD=sqrt(3).*stddelt./sqrt(n);
dFree=n-1;
P=1-0.95;
t=marray_AStudT(P,dFree);
cof_int_meandiff1=meandelt-(t*stderror);
cof_int_meandiff2=meandelt+(t*stderror);
cof_int_meandif=[cof_int_meandiff1,cof_int_meandiff2];

cof_int_lower1=(meandelt-2*stddelt)-(t*stderror2SD);
cof_int_lower2=(meandelt-2*stddelt)+(t*stderror2SD);
cof_int_lower=[cof_int_lower1,cof_int_lower2];

cof_int_upper1=(meandelt+2*stddelt)-(t*stderror2SD);
cof_int_upper2=(meandelt+2*stddelt)+(t*stderror2SD);
cof_int_upper=[cof_int_upper1,cof_int_upper2];

%%%%%%%%%%%%%%
%start plot 
%
figure(surf_fig2)
%clf;
er=t*stderror*ones(size(linex));
errorbar(linex,liney,er,'c-');
%plot(linex,liney,'-');
hold on;
er2=t*stderror2SD*ones(size(linex));
%plot(linex,liney2std,'g-');
errorbar(linex,liney2std,er2,'r-');
hold on;
%plot(linex,liney2std2,'g-');
%added 10/08/01
errorbar(linex,liney2std2,er2,'r-');
hold on;
plot(meanInt,delt,'.');
%plot(meanInt,di,'.');
hold on;
plot([min_meanInt,min_meanInt],[miny-0.25 maxy+0.25 ],'g-')

if minx<maxx & miny<maxy
  axis([0 maxx miny-0.25 maxy+0.25]);
end

if islog2==1 
   ylabel('Exp1-Exp2');
   xlabel('Cubic_{root}((R1*G1+R2*G2)/2)');
elseif islog2==0    
   xlabel('Cubic_{root}(R1*G1+R2*G2)/2)');
   ylabel('log2(Exp1)-log2(Exp2)');
elseif islog2==2
    ylabel('Cubeic_{root}(Exp1-Exp2)');
   xlabel('Cubic_{root}((R1*G1+R2*G2)/2)');
end
 i=[];
nt=[];
%[m,s,mm,ss]=normfit(real(delt),0.1);
%[h,i]=normplot2(delt);
%nt=[mm,ss];
t_test= (meandelt-zeros(size(meandelt)))./stderror;
p=marray_StudT(abs(t_test),dFree);

