function [results, id]=marray_searchlog(newx,newy,x,y,Z,name,isprint)
global genecell2 htxt2 ind1 filename3 file1
%search in Vector x, and y find
% correlated Z strings for (newx,newy)
%
temp='No';
%find min distance
%[minds id]= min(sqrt((x-newx*ones(size(x))).^2+(y-newy*ones(size(y))).^2))
flagindex=zeros(length(x),1);


xlimit=abs(x-newx*ones(size(x)))./abs(x);
ylimit=abs(y-newy*ones(size(y)))./abs(y);
[minvalue id] =min(xlimit+ylimit);
limit=0.05;
if minvalue<=limit
  temp=char(Z(id,:));
  tempname=char(name(id,:));
  %Added JBW
  tempID=char(Z(id,:));
  tempGname=char(name(id,:));
 
  lineIndex=marray_findlinefeed(temp);
  tabIndex=marray_findtab(temp);
  
  ntabIndex=marray_findtab(tempname) ;  
  if isempty(lineIndex) ~=1 
    temp=temp(lineIndex+1:length(temp));
  end
  if isempty(tabIndex)~=1
     temp=temp(1:tabIndex-1);
  end
  
  if isempty(ntabIndex)~=1 & length(ntabIndex)>1
     tempname=tempname(1:ntabIndex(2)-1);   
  end;
   
end
if strcmp(temp,'No')~=1
    %tempid=findstr(tempname,' '); %changed 12/07/01
    tempid=findstr(tempname,'_');
    lntemp=length(tempname);
    if isempty(tempid)
      name=tempname;
      id=tempname;
    else
      id=deblank(tempname(1:tempid(1)-1));
      name=deblank(tempname(tempid(1)+1:lntemp));
    end
   %disp([' ColID: ', id, ', Gene Name: ', name]);
   %Added JBW
   id=deblank(tempID);
   name=deblank(tempGname);
   
   genecell2={[char(10),' IMAGE:',char(9),id,char(9),' Gene Name: ', name]};
   ind1=1; %it's for clone2www.
   filename3=file1; %it's for clone2www
   if nargin<=6
    set(htxt2,'String',genecell2);
   end
   %disp('  ');   
   %results=temp; %changed 12/07/01
   results=id;
else
   results='None';
end

