    ir = 0;
    if (ltp > 0)
% remove old paths
        for i=1:ltp
            rpth = temp(tempc(length(tempc)-ir)+1:length(temp));
            temp = temp(1:tempc(length(tempc)-ir)-1);
            ir = ir + 1;
            rmpath(rpth);
        end
    end
