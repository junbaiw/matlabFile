function returnIndex=marray_findreturn(str)
%find the position of return
returnIndex=findstr(str,char(13)) ;
