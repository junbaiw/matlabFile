function printData(OutFid,strForm,string2_data,rownames,tempdata)
fprintf(OutFid,strForm,string2_data);

