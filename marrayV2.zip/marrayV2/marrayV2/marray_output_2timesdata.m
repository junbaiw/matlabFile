function result=marray_output_2timesdata(outname,newratio,newnamestr,newColIDstr)
global table

OUTfid=fopen([outname],'w'); 

%disp(['Output ratios which are 2 times away from the center in log2 scale: out/', outname]);
marray_debuge(['Output ratios which are 2 times away from the center in log2 scale: out/', outname]);
k=length(newratio);
for jj=1:k
   temp=newnamestr(jj,:);
   Ixtemp=marray_findlinefeed(temp);
   ltemp=length(temp);
   if (newratio(jj,1)/newratio(jj,2)>4 | newratio(jj,1)/newratio(jj,2)<0.25)
     if isempty(Ixtemp)
      fprintf(OUTfid,'%s %s %f %s %f \n',temp,char(9),...
         newratio(jj,1),char(9),newratio(jj,2) );
     else    
      fprintf(OUTfid,'%s %s %f %s %f \n',temp(Ixtemp+1:ltemp),char(9), ...
         newratio(jj,1),char(9),newratio(jj,2) );
     end
   end
end
fclose(OUTfid);
