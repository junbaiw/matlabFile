function tabIndex=marray_findtab(str)
%find the position of tab
tabIndex=findstr(str,'	') ;
