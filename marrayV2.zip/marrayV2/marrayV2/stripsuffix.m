function [s2,suffix]=stripsuffix(s1)
%s2=stripsuffix(s1)
%returns string with 4 or fewer suffix characters stripped
%suffix begins with last '.' period 
l1=findstr(s1,'.'); %list of positions of '.' in string
n=length(s1);
   if n-max(l1)<=5
	%strip suffix
	s2=s1(1:max(l1)-1);
	else
	s2=s1;
	end
