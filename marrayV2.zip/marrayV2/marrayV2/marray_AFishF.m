function f=marray_AFishF(p,n1,n2) 
% 
%Probability of Fisher F-Distribution, input: p is the probability ,
% n1 is number of groups, n2 is the total number
% of subjects in experiment minues number of groups.
% output is the F-distributions for p probability.
%

v=0.5; dv=0.5;  f=0;
while dv>1e-6 
   f=1/v-1; dv=dv/2; 
   if marray_FishF(f,n1,n2)>p
      v=v-dv ;
   else  
      v=v+dv;  
   end
 end
