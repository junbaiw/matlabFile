function colname=marray_tabassign2(tempdata2,colnum)
%colnum=num of column
%tempdata2= line scane
%clear colname tl;
%tempdata2=tline;
%colnum=20;

tl=strrep(deblank(tempdata2),' ','_');
lntemp=length(tl);

i=1;
NEXTINDEX=0;
while i<=colnum
    if i==1
      [A,COUNT,ERRMSG,NEXTINDEX] =sscanf(tl(1:lntemp),'%s[^\t]');
      totIDX=NEXTINDEX+1;
    else 
      [A,COUNT,ERRMSG,NEXTINDEX] =sscanf(tl(totIDX:lntemp),'%s[^\t]');
      totIDX=totIDX+NEXTINDEX   ; 
  end
colname{i}=A;
i=i+1;
end

%colnum=33;
%tempdata2=deblank(tempdata2);
%titlestring=tempdata2;
%tabIndx=marray_findtab(titlestring);
%lntab=length(tabIndx);
%lnstring=length(titlestring);

%colIndx=1:colnum-2;
%colIndx2=1:colnum-1;
%tb_bg(1)=1;
%tb_bg(2:length(colIndx)+1)=tabIndx(colIndx);
%tb_end=tabIndx(colIndx2);
%str_inform= ['''', repmat('%s',[1 colnum-1]) '%s','''']
%str_inform=[ repmat('%s',[1 colnum-1]) '%s']
%str_outform=cellstr([repmat('g',colnum,1) strjust(num2str((1:colnum)'),'left')  repmat(',',colnum,1) ])
%str_outform(colnum)=strrep(str_outform(colnum),',','');
%out_str=['[ ' str_outform ' ]'] 
%colname=[a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,z1,z2,z3,z4,z5,z6,z7];
%[a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,z1,z2,z3,z4,z5,z6,z7]= strread(li,str_inform,'delimiter','\t\n','whitespace','')
%colname=[a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,z1,z2,z3,z4,z5,z6,z7];



