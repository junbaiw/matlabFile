function marray_scatterlog2(x,y,newintensity,Z,namestr,islog2,tmp_di,idx_di,min_ch11,min_ch12,min_ch21,min_ch22);
%There is a bug surf_fig2 at here!!!! 31/07/2001
%scatterlog(x,y,Z) Interactive log10 plot of a data grid.
%Original written by    
%   B.A. Jones 5-23-93
%   Copyright (c) 1993-98 by The MathWorks, Inc.
%   $Revision: 2.9 $  $Date: 1998/05/26 20:52:39 $
%modified by Junbai Wang 10-2000 for DNR microarray plot
%x,y is the data point of two experiment
%Z is string for ColID
%name is string for Gene name
%ch1orch2, Compare channel 1 =1, compare Channel 2 =2;
%islog, Chose log scale plot =1, chose plot=0;
%RI, Compare Ratio =1 or Intensity =2;
%There is a bug in close 311000_jbw
global oldz2 oldx2 oldy2 name2 id2 surf_fig2 oldintensity old_tmp_di old_idx_di

ch1orch2=2;
if ~isstr(x) 
    action = 'start';
    oldx2=x; oldy2=y;  oldz2=Z; name2=namestr; 
    oldintensity=newintensity; old_tmp_di=tmp_di; old_idx_di=idx_di;
else
      action = x;   
end
   %size(oldx),size(oldy),size(oldz),size(name)
   %sprintf('In scater 2 %d',min(oldx-oldy))   
 
%On recursive calls get all necessary handles and data.
if ~strcmp(action,'start')   
   surf_fig2 = findobj('Tag','surf_fig2');
   f = get(surf_fig2,'Userdata');

   x_field          = f(1);
   y_field          = f(2);
   z_field          = f(3);
   xtext            = f(4);
   ytext            = f(5);
   ztext            = f(6); 
   surf_axes        = f(7);      
   xgrid = get(xtext,'UserData');
   ygrid = get(ytext,'UserData');
   zgrid = get(ztext,'UserData');
   h     = get(surf_axes,'UserData');
   vwitnessline = h(1);
   hwitnessline = h(2);

    xrange = get(surf_axes,'XLim');
    yrange = get(surf_axes,'YLim');

    newx = str2double(get(x_field,'String'))  ;
    newy = str2double(get(y_field,'String'))  ;    
end

if strcmp(action,'start'),

% Set positions of graphic objects
axisp   = [.20 .15 .79 .74];
xfieldp = [0.7 .0 .14 .06];
yfieldp = [0.02 .93 0.14 .06];
zfieldp = xfieldp + [0. .93 0.02 0];
%zfieldp=[0.6 .930 .14 .06];

   
      
surf_fig2 = figure(4);
clf(surf_fig2);
set(surf_fig2,'position',[700 55 300 300]);

whitebg(surf_fig2, [0 0 0]);
set(surf_fig2,'Units','Normalized','Tag','surf_fig2');
fcolor  = get(surf_fig2,'Color');

surf_axes = axes;

% Set axis limits and data
if nargin == 1
    [m, n] = size(x);
   Z = x;
   x = 1:m;
   y = 1:n;
   xrange = [1 m];
   yrange = [1 n];
else
   %Bug
   %xrange        = [x(1) x(length(x))];
   %yrange        = [y(1) y(length(y))];
   xrange=[min(real(x)) max(real(x))];
   yrange=[min(real(y)) max(real(y))];
end
%[xgrid ygrid] = meshgrid(x,y);
%Bug 2410
xgrid=min(real(x)):0.01:max(real(x));

% Define graphics objects
        
x_field=uicontrol('Style','edit','Units','normalized','Position',xfieldp,...
         'BackgroundColor','white','Userdata',mean(xrange),...
         'CallBack','scatterlog2(''editX'')');
         
y_field=uicontrol('Style','edit','Units','normalized','Position',yfieldp,...
         'BackgroundColor','white','Userdata',mean(yrange),...
         'CallBack','scatterlog2(''editY'')');

z_field=uicontrol('Style','text','Units','normalized','Position',zfieldp,...
         'BackgroundColor',fcolor,'ForegroundColor','w');
      
     xtext   =uicontrol('Style','text','Units','normalized',...
        'Position',xfieldp + [-1.0 0.0 0 0],'BackgroundColor',fcolor,...
        'ForegroundColor','w','UserData',xgrid);
        
   ytext   =uicontrol('Style','text','Units','normalized',...
       'Position',yfieldp + [-1.0 0.0 0 0],'BackgroundColor',fcolor,...
        'ForegroundColor','w','String','','UserData',ygrid);  
ztext   =uicontrol('Style','text','Units','normalized',...
        'Position',zfieldp + [-0.16 0.0 0 0],'BackgroundColor',fcolor,...
        'ForegroundColor','w','String','Col_ID ','UserData',Z);
         
 
     [t_test, sortidx,nt]=marray_test_norm(old_tmp_di,old_idx_di,x,y,newintensity,islog2,surf_fig2,min_ch11,...
         min_ch12,min_ch21,min_ch22);
       
%Bug here
%set(gca,'Units','normalized','Position',axisp,'XLim',sort(xrange),'YLim',sort(yrange),'Box','on');
set(gca,'NextPlot','add','DrawMode','fast','Gridlinestyle','-');

%   Create Witness Lines
yvertical = [yrange(1) yrange(2)]';
xvertical = ones(size(yvertical)) * (xrange(1) + xrange(2))/2;

newx  = xvertical(1);
newy  = (yrange(1) + yrange(2))/2;

set(x_field,'String',num2str(newx));
set(y_field,'String',num2str(newy));
 
[newz ,id2]=marray_searchlog2(newx,newy,oldx2,oldy2,oldintensity,oldz2,name2,old_tmp_di);
set(z_field,'String',num2str(newz));  
  
xhorizontal = [xrange(1) xrange(2)]';
yhorizontal = newy * ones(size(xhorizontal));

vwitnessline = plot(xvertical,yvertical,'w-.','EraseMode','xor');
hwitnessline = plot(xhorizontal,yhorizontal,'w-.','EraseMode','xor');

set(vwitnessline,'ButtonDownFcn','marray_scatterlog2(''down'')');
set(hwitnessline,'ButtonDownFcn','marray_scatterlog2(''down'')');

set(gcf,'Backingstore','off','WindowButtonMotionFcn','marray_scatterlog2(''motion'',0)');
set(gcf,'WindowButtonDownFcn','marray_scatterlog2(''down'')');

set(surf_fig2,'Userdata',[x_field;y_field;z_field;xtext; ...
      ytext;ztext;surf_axes],'HandleVisibility','callback'); %flag

set(surf_axes,'UserData',[vwitnessline;hwitnessline]);


% End of initialization activities.
elseif strcmp(action,'motion'),
    if y == 0,
      cursorstate = get(gcf,'Pointer');
        cp = get(gca,'CurrentPoint');
        cx = cp(1,1);
        cy = cp(1,2);
        fuzzx = 0.01 * (xrange(2) - xrange(1));
        fuzzy = 0.01 * (yrange(2) - yrange(1));
        online = cy > yrange(1) & cy < yrange(2) & cx > xrange(1) & cx < xrange(2) &...
           ((cy > newy - fuzzy & cy < newy + fuzzy) | (cx > newx - fuzzx & cx < newx + fuzzx));
        if online & strcmp(cursorstate,'arrow'),
            set(gcf,'Pointer','crosshair');
        elseif ~online & strcmp(cursorstate,'crosshair'),
            set(gcf,'Pointer','arrow');
        end
    
    elseif y == 1
        cp = get(gca,'CurrentPoint');
        newx=cp(1,1);
        if newx > xrange(2)
            newx = xrange(2);
        end
        if newx < xrange(1)
            newx = xrange(1);
        end

        newy=cp(1,2);
        if newy > yrange(2)
            newy = yrange(2);
        end
        if newy < yrange(1)
            newy = yrange(1);
        end
       
    [newz, id2]=marray_searchlog2(newx,newy,oldx2,oldy2,oldintensity,oldz2,name2,old_tmp_di);
        set(x_field,'String',num2str(newx));
        set(x_field,'Userdata',newx);
        set(y_field,'String',num2str(newy));
        set(y_field,'Userdata',newy);
        set(z_field,'String',num2str(newz));
       
        set(vwitnessline,'XData',newx*ones(size(yrange)),'YData',yrange);
        set(hwitnessline,'XData',xrange,'YData',newy*ones(size(xrange)));

     end

elseif strcmp(action,'down'),
    set(gcf,'Pointer','crosshair');
    cp = get(gca,'CurrentPoint');
    newx=cp(1,1);
    if newx > xrange(2)
       newx = xrange(2);
    end
    if newx < xrange(1)
       newx = xrange(1);
    end

    newy=cp(1,2);
    if newy > yrange(2)
       newy = yrange(2);
    end
    if newy < yrange(1)
       newy = yrange(1);
    end
    
    [newz, id2]=marray_searchlog2(newx,newy,oldx2,oldy2,oldintensity,oldz2,name2,old_tmp_di);
    set(x_field,'String',num2str(newx));
    set(x_field,'Userdata',newx);
    set(y_field,'String',num2str(newy));
    set(y_field,'Userdata',newy);
    set(z_field,'String',num2str(newz));
    
    set(vwitnessline,'XData',newx*ones(size(yrange)),'YData',yrange);
    set(hwitnessline,'XData',xrange,'YData',newy*ones(size(xrange)));
   
    set(gcf,'WindowButtonMotionFcn','marray_scatterlog2(''motion'',1)');
    set(gcf,'WindowButtonUpFcn','marray_scatterlog2(''up'')');
   
 elseif strcmp(action,'up'),
   if  ~strcmp(action,'close')
    set(gcf,'WindowButtonMotionFcn','marray_scatterlog2(''motion'',0)');
    set(gcf,'WindowButtonUpFcn','');
   end
 
elseif strcmp(action,'editX'),
    if isempty(newx) 
      newx = get(x_field,'Userdata');
      set(x_field,'String',num2str(newx));
       return;
   end
    if newx > xrange(2)
        newx = xrange(2);
        set(x_field,'String',num2str(newx));
    end
    if newx < xrange(1)
        newx = xrange(1);
        set(x_field,'String',num2str(newx));
    end
    
    [newz, id2]=marray_searchlog2(newx,newy,oldx2,oldy2,oldintensity,oldz2,name2,old_tmp_di);
    set(x_field,'Userdata',newx);
    set(z_field,'String',num2str(newz));
    set(vwitnessline,'XData',newx*ones(size(yrange)));
    
elseif strcmp(action,'editY'),
    if isempty(newy) 
      newy = get(y_field,'Userdata');
      set(y_field,'String',num2str(newy));
       return;
   end
    if newy > yrange(2)
        newy =  yrange(2);
        set(y_field,'String',num2str(newy));
    end
    if newy <  yrange(1)
        newy =  yrange(1);
        set(y_field,'String',num2str(newy));
    end
     
    [newz, id2]=marray_searchlog2(newx,newy,oldx2,oldy2,oldintensity,oldz2,name2,old_tmp_di);
    set(z_field,'String',num2str(newz));
    
    set(hwitnessline,'XData',xrange,'YData',newy*ones(size(xrange)));
    set(y_field,'Userdata',newy);
    
%    set(flag_field,'String',num2str(flagV)); %flag
   
 elseif strcmp(action,'stray_click'),
   set(gcf,'CurrentAxes',surf_axes);%
end     % End of long "case" statement.


