function result=marray_findTitle(filename)
%
%filename='Export1710.txtTitle.txt'
fid=fopen(filename);
data=fscanf(fid,'%c');
tabIndex=findtab(data);
lenoftab=length(tabIndex);
for i=1:lenoftab
   if i==1
      result{i,1}=data(1:tabIndex(1)-1);
   else
      result{i,1}=data(tabIndex(i-1)+1:tabIndex(i)-1);
   end
end
