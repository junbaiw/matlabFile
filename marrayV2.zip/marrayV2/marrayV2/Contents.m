% MArray Toolbox
% Version 1.01, Feb 1 2002
% 
% Copyright 2000-2002 by 
% Contributed from Junbai Wang

