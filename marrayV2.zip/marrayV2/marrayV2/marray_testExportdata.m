function marray_testExportdata(data,colnames,rownames,exportFileName)
%
%Export data file in tab deliminate format

%colnames=strvcat(sel_files)
%rownames=id_name;
%exportFileName='selected_test.dat'

%%
OutFid=fopen(exportFileName,'W');
[lnRow lnCol]=size(data);

%make export format
string1='';
string1=[string1,repmat('%s',1,lnCol*2+1)];
string1=[string1,'\n',''];
for i=1:lnCol+1
    if i==1
        string2=['''','CloneID','''',',','char(9)'];
        string2_data=['deblank(rownames(ki,:))',',','char(9)'];
    elseif i==lnCol+1
        string2=[string2,',','''',deblank(colnames(i-1,:)),''''];
        string2_data=[string2_data,',','tempdata(',num2str(i-1),')'];
    else
        string2=[string2,',','''',deblank(colnames(i-1,:)),'''',',','char(9)'];
        string2_data=[string2_data,',','tempdata(',num2str(i-1),')',',','char(9)'];
    end
end
%modifed Oct 2004
printString=['fprintf(OutFid,','''',string1,'''',',',string2,');'];
eval(printString);
printData=['fprintf(OutFid,','''','%s%s',repmat('%f%s',1,lnCol-1),'%f\n','''',',',string2_data,');'];

for ki=1:lnRow
    tempdata=data(ki,:);
   eval(printData);
end
result=fclose(OutFid);
    
