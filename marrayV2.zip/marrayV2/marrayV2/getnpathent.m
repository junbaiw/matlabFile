%find number fscan1.2/ entries in path
    if (isunix)
       tempp = findstr(temp,'F-SCAN 1.2/');
       if (isempty(tempp))
	 tempp = findstr(temp,'F-SCAN_1.2/');
       end
       tempc = findstr(temp,':');
    elseif (strcmp(ostyp,'PCWIN') > 0)
    	  tempp = findstr(temp,'F-SCAN 1.2\');
	  if (isempty(tempp))
	     tempp = findstr(temp,'F-SCAN_1.2\');
          end
          tempc = findstr(temp,';');
    elseif (strcmp(ostyp,'MAC') > 0)
      	  tempp = findstr(temp,'F-SCAN 1.2:');
	  if (isempty(tempp))
	     tempp = findstr(temp,'F-SCAN_1.2:');
          end
          tempc = findstr(temp,';');
    else
         disp('Operating system not found')
    end
    ltp = length(tempp);
% all mac path entries end with :
    if (strcmp(ostyp,'MAC') > 0)
          ltp = ltp - 1;
    end
