function Export_fileInformation(outfname,data,table)

outname=[outfname,'_info'];
infoid=fopen([outname],'w');
lninfo=size(data.userInfo,1);
for k=1:lninfo
   fprintf(infoid,'%s \n',strrep(data.userInfo(k,:),char(10),''));
end
lntable=size(table,1);
for k=1:lntable
  fprintf(infoid,'%s \n',strvcat(table(k,:)));
end
fclose(infoid);
