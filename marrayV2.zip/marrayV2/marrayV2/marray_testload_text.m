function [inputdata,outputdata,numofSpots]=marray_testload_text(filename)
%deblank
% the input text file should be tab deliments text file format
%otherwise this function will not work.
%replace NA as 999999999
%Version 3.0
%clear tempdata inputdata outputdata

t0=clock;
%filename
%filename='pax6_2_1_Dec19_colorswap_anal_nohead.txt'                                                                
%65_ps18_271101.gpr

%tempdata=[];
%inputdata=[];
%outputdata=[];
[fid,msg]=fopen(filename,'rt');
if fid<0
    error('Can not open file');
end
idx=1;
findInf=0;
temp=[];
while 1
    tline = fgets(fid);
    if ~ischar(tline)
        break,
    end
    if findInf==0
       %indeximage=strmatch('Block',tline);
       %indeximage=findstr('Block',tline);
      indeximage=1; 
	if isempty(indeximage)
          tempdata{idx}=tline;
       else
         if indeximage==1
           userInfo='Not available'; %read info
           findInf=1;
           dataidx=idx;
         else
          userInfo=strvcat(tempdata); %read info
          findInf=1;
          dataidx=idx; 
         end
          
          colname=marray_tabassign(tline,1);   %read column
          lncolname=length(colname);
          repidx=strmatch('Rgn_R',colname);
          for i=1:length(repidx)
              if strcmp(colname{repidx(i)},'Rgn_Ratio')~=1
              colname{repidx(i)}='Rgn_Ratio_squre';
              end
          end

          for i=1:lncolname
            tempname=strrep(deblank(colname{i}),'._','');
            tempname=strrep(tempname,' ','_');
            tempname=strrep(tempname,'.','');
            tempname=strrep(tempname,'%','Pr');
            tempname=strrep(tempname,'+','Plus');
            tempname=strrep(tempname,'-','Minus');
            tempname=strrep(tempname,'>','Gt');
            tempname=strrep(tempname,'(',''); %added May 06 2002
            tempname=strrep(tempname,')','');
            tempname=strrep(tempname,'/','v');
            tempname=strrep(tempname,'\','v');
            tempname=strrep(tempname,'?','');
	    tempname=strrep(tempname,'"','');
	   tempname=strrep(tempname,'&','_');
	   tempname=strrep(tempname,',','');
           tempname=strrep(tempname,'0','o'); 
           colname{i}=tempname;
         end
         tempdata2=cell(1,16000);
         tempdata2{1}=tline;
         temp=cell(16000,lncolname);
      end
     end  %end if Block
     
     if findInf==1 & idx-dataidx>0
         %read data
          vardata=tline;
          vardata=strrep(vardata,'"NA"','999999999');
          vardata=strrep(vardata,'NA','999999999');
          tempdata2{idx-dataidx+1}=vardata;
          %eval(str_load);
          %eval(['varcol='str11 ';']);
          varcol=marray_tabassign2(vardata,lncolname);
          temp(idx-dataidx,:)=varcol(:);              
     end     
    idx=idx+1;
end
fclose(fid);

inputdata=struct('inputdata',filename);
for j=1:lncolname
     tempname=strvcat(colname{j});
     tempData=temp(1:idx-dataidx-1,j);
     %modifed Oct2004
     inputdata=setfield(inputdata,tempname,tempData); 
%	eval(['inputdata.',tempname,'=temp(1:idx-dataidx-1,j);']);
%end modif
end
outputdata=tempdata2(1,1:idx-dataidx);
numofSpots=length(['inputdata.',tempname]);
inputdata.userInfo=userInfo;
tt=etime(clock,t0); 
