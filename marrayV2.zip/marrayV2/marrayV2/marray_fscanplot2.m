function marray_fscanplot2(outfname,path1,imagefnames,data,File1_form,imageForm)

%Start load QuantArray output file and transfer it
% to fscan format
%outdata=loadFile2fscan(outfname,path1);
outdata=data;
%make .mat fiile for fscan
if File1_form==1
    fscandata(:,1)=str2num(strvcat(outdata.Array_Row));
    fscandata(:,2)=str2num(strvcat(outdata.Array_Column));
    fscandata(:,3)=str2num(strvcat(outdata.Row));
    fscandata(:,4)=str2num(strvcat(outdata.Column));
    fscandata(:,5)=str2num(strvcat(outdata.Y_Location))./10; % this should check it later!! 01/08/001
    fscandata(:,6)=str2num(strvcat(outdata.X_Location))./10;
    fscandata(:,7)=str2num(strvcat(outdata.ch1_Intensity));
    fscandata(:,8)=str2num(strvcat(outdata.ch1_Background));
    fscandata(:,9)=str2num(strvcat(outdata.ch2_Intensity));
    fscandata(:,10)=str2num(strvcat(outdata.ch2_Background));
elseif File1_form==2
    fscandata(:,1)=str2num(strvcat(outdata.Block));
    fscandata(:,2)=str2num(strvcat(outdata.Column));
    fscandata(:,3)=str2num(strvcat(outdata.Row));
    fscandata(:,4)=str2num(strvcat(outdata.Column));
    fscandata(:,5)=str2num(strvcat(outdata.Y_Location))./10; % this should check it later!! 01/08/001
    fscandata(:,6)=str2num(strvcat(outdata.X_Location))./10;
    fscandata(:,7)=str2num(strvcat(outdata.ch1_Intensity));
    fscandata(:,8)=str2num(strvcat(outdata.ch1_Background));
    fscandata(:,9)=str2num(strvcat(outdata.ch2_Intensity));
    fscandata(:,10)=str2num(strvcat(outdata.ch2_Background));
end

M1=fscandata;
%imagefname='mscan.tif';
%Tdtc=imread(imagefnames,'tif'); %tif format in RGB mode
radius=14.4864;
cd(path1);
eval(['save ',outfname,'fscan.mat ','M1 radius']); % make .mat file for fscan 

%make genelist for fscan
genename=outdata.Name;
numofSpots=length(genename);
leng=numofSpots;
if File1_form==1
    [id,name]=marray_Separate_ID_Name(genename,numofSpots);
end
cloneid{1}='cloneid';
gname{1}='Genename';
plate{1}='plate';
address{1}='address';
field{1}='field';
row{1}='row';
column{1}='column';
if File1_form==1
    numofArrayRow=str2num(strvcat(outdata.Array_Row(end))); 
    numofArrayCol=str2num(strvcat(outdata.Array_Column(end)));
end
for i=1:leng
    if File1_form==1
        %tempname=genename(i,:);
        %[id,name]=marray_Separate_ID_Name(tempname,numofSpots)
        %tempname=genename(i,:);
        %tempid=findstr(tempname,' ');
        %lntemp=length(tempname);
        %if ~isempty(tempid)
        %    id=deblank(tempname(1:tempid(1)-1));
        %    name=deblank(tempname(tempid(1)+1:lntemp));
        %else
        %       id=deblank(tempname(1:tempid(1)-1));
        %    name=deblank(tempname(tempid(1)+1:lntemp));
        %end     
        cloneid{i+1}=['IMAGE:',strvcat(id{i})];
        gname{i+1}=strvcat(name{i});
    elseif File1_form==2
        cloneid{i+1}=['IMAGE:', strvcat(outdata.ID{i})];
        gname{i+1}=strvcat(outdata.Name{i});
    end
    
    plate{i+1}=['Ratio: ', num2str(outdata.Ratio(i)),',',';', 'Int1: ',num2str(outdata.Ch1_BacksubIntensity(i)),', Int2: ',...
            num2str(outdata.Ch2_BacksubIntensity(i))] ;
    address{i+1}=['Q_com: ', num2str(outdata.q_com(i)), ',',';','Q_com1: ',num2str(outdata.q_com1(i)),', Q_com2: ', ...
            num2str(outdata.q_com2(i))];
    if File1_form==1
         field{i+1}= ['Array: ', num2str(str2num(strvcat(outdata.Array_Column(i)))+(str2num(strvcat(outdata.Array_Row(i)))-1)*numofArrayCol)];
    elseif File1_form==2
         field{i+1}=  ['Array: ', outdata.Block{i}  ];
    end
   % row{i+1}=['Row:' ,num2str(outdata.row(i)),'q1_bk: ',num2str(outdata.q1_bk(i)),'q1_sg: ',num2str(outdata.q1_sg(i)),...
   %         'q1_sg_bk:',num2str(outdata.q1_sg_bk(i))];
   % column{i+1}=['Column: ',num2str(outdata.column(i)),'q2_bk: ',num2str(outdata.q2_bk(i)),'q2_sg: ',num2str(outdata.q2_sg(i)),...
   %         'q2_sg_bk:',num2str(outdata.q2_sg_bk(i))];
   row{i+1}=['Row:' ,num2str(str2num(strvcat(outdata.Row(i))))];
   column{i+1}=['Column: ',num2str(str2num(strvcat(outdata.Column(i))))]; 
end
outfscname=[outfname,'.fsc'];
OUTfid=fopen([outfscname],'wt+'); 
for i=1:leng+1
        fprintf(OUTfid,'%s%s%s%s%s%s%s%s%s%s%s%s%s \n', ...
            gname{i},char(9),cloneid{i},char(9),plate{i},char(9),address{i},char(9), ...
            field{i},char(9),row{i},char(9),column{i});
end
fclose(OUTfid);

%start load data for fscan
F1=[outfname,'fscan.mat'];
F3=[outfname,'.fsc'];
P1=path1;
P3=path1;
marray_compare(F1,P1,F3,P3,imagefnames,imageForm);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%load mscanout.txt %spots location and intensity 
%M1=mscanout;
%Tdtc=imread('mscan.tif','tif');
%radius=14.4864;
%save testMscan M1 Tdtc radius

%F1='mscansample.mat';
%F1='testMscan.mat';
%F3='mscan.fsc'; %gene names and spot locations
%P3=[pwd,'\'];
%P1=[pwd,'\'];
%compare(F1,P1,F3,P3)
