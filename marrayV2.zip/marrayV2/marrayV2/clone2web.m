function clone2web(genecell,ind1,filename3)
%global genecell ind1 filename3
temp = findstr(genecell{ind1},char(9));
    % current cell is 1 genename 2 clone 3 plate 4 NCI-LCaddr 5-7 address(F R C)
clne     = genecell{ind1}(temp(1)+1:temp(2)-1);
temp = findstr(clne,'IMAGE:');
if (findstr(filename3,'Mm'))
  if (isempty(temp))
    url     = ['http://nciarray.nci.nih.gov/cgi-bin/UG_query.cgi?ORG=Mm&CRITERIA=CLONE&PARAMETER=IMAGE:' clne];
  else
    url     = ['http://nciarray.nci.nih.gov/cgi-bin/UG_query.cgi?ORG=Mm&CRITERIA=CLONE&PARAMETER=' clne];
  end
else
  if (isempty(temp))
    url     = ['http://nciarray.nci.nih.gov/cgi-bin/UG_query.cgi?ORG=Hs&CRITERIA=CLONE&PARAMETER=IMAGE:' clne];
  else
    url     = ['http://nciarray.nci.nih.gov/cgi-bin/UG_query.cgi?ORG=Hs&CRITERIA=CLONE&PARAMETER=' clne];
  end
end
web(url);


